#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import gc
import logging
import os
import re
import sys
import threading
import time
from webserver.handlers import static_files
from webserver.i18n import _
from logging.handlers import RotatingFileHandler
import traceback

import tornado.httpserver
import tornado.ioloop
import tornado.log
from tornado.httpclient import AsyncHTTPClient
from social_tornado.models import init_social
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import scoped_session, sessionmaker
from tornado import web
from tornado.options import define, options

from webserver import loader, models, perf, social_routes, startup_status
from webserver.startup_status import StartupState, substep
from webserver.services import warmup
from webserver.services.perf_monitor import PerfMonitor
from webserver.base.setting_saver import SettingsSaver
from webserver.base import db_diagnosis
from webserver.services import AsyncService
from webserver.services.book_barn import BookBarnService
from webserver.services.item_sync import ItemSyncService
from webserver.services.resource_service import ResourceService
from webserver.recommend import CalibreFeatureSource, RecommendConfig, RecommendService, SqlCrowdSource, SqlProfileSource
from webserver.constants import COLUMN_CATEGORY, COLUMN_FOLDER, COLUMN_PHY_COUNT, COLUMN_BOOK_TYPE, COLUMN_TRANSLATORS
from webserver.constants import COLUMN_EXT_LINK, CUSTOM_COVER_IMAGE, COLUMN_DYNAMIC_COVER
from webserver.constants import COLUMN_LOCATION, COLUMN_CATALOG, COLUMN_AUTHOR_LOCKED, COLUMN_NARRATOR
from webserver.version import VERSION


def should_check_db_structure(conf, version):
    """启动时是否需要检查/升级表结构。

    **永远是 True。** 这不是偷懒，是因为「用版本号判断表结构新旧」这个
    思路本身就是错的：

    - 我们出包时 `VERSION` 经常不动（r9 → r11 一直是 `v4.8.0`），
      但模型里加了列。版本号相同 → 判定「不是升级」→ 整块迁移被跳过
      → 任何 `SELECT readers.*` 直接 `no such column`。
      **r11 在 NAS 上就是这么挂的（2026-11-05）。**
    - 反向也会错：只改版本号、没改模型，白跑一遍迁移（无害但没必要）。

    所以判定依据应该是「表结构实际是什么样」，而不是「版本号字符串」。
    而 `adjust_*_table()` 里每一步都是 `if "列名" not in columns` 的
    **幂等检查**，跑一遍的代价只是几次 `PRAGMA table_info`（毫秒级），
    跑与不跑之间没有性能上的取舍。

    保留这个函数而不是直接内联 `need_check_db=True`，是为了留一个
    可测、可注释、可被测试钉住的接缝——免得日后有人「优化」回
    `!= VERSION`。
    """
    return True


CONF = loader.get_settings()
define("host", default="", type=str, help=_("The host address on which to listen"))
define("port", default=8080, type=int, help=_("The port on which to listen."))
define(
    "path-calibre",
    default="/usr/lib/calibre",
    type=str,
    help=_("Path to calibre package."),
)
define(
    "path-resources",
    default="/usr/share/calibre",
    type=str,
    help=_("Path to calibre resources."),
)
define(
    "path-plugins",
    default="/usr/lib/calibre/calibre/plugins",
    type=str,
    help=_("Path to calibre plugins."),
)
define(
    "path-system-plugins",
    default="/usr/lib/calibre/mybooks-plugins",
    type=str,
    help=_("Path to MyBooks calibre plugin zips (e.g. DjVu metadata)."),
)
define(
    "path-bin", default="/usr/bin", type=str, help=_("Path to calibre binary programs.")
)
define(
    "with-library",
    default=CONF["with_library"],
    type=str,
    help=_("Path to the library folder"),
)
define("syncdb", default=False, type=bool, help=_("Create all tables"))
define(
    "update-config",
    default=False,
    type=bool,
    help=_("update config when system upgrade"),
)

# Set the maximum memory allocation for Qt image processing to prevent crashes with large images
os.environ["QT_IMAGEIO_MAXALLOC"] = "400"


def drop_old_table_as_needed(session):
    if not session:
        return
    result = session.execute(text("""
        PRAGMA table_info(items)
    """)).fetchall()
    columns = [row[1] for row in result]
    if "scope" not in columns:
        return
    session.execute(text("""
        DROP TABLE items
    """))


def add_meta_in_calibre(calibre_db, key, name, datatype):
    found = False
    for k, v in calibre_db.field_metadata.items():
        if k.startswith("#") and k.lstrip("#") == key:
            found = True
            break
    if found:
        logging.info("No need to create key: [%s] in calibre, already exists." % key)
        return False
    try:
        calibre_db.create_custom_column(label=key, name=name, datatype=datatype, is_multiple=False)
    except Exception as e:
        logging.error(f"Error creating custom field: {e}")
        return False
    return True


def config_calibre():
    from calibre.db.backend import DB

    db = DB(options.with_library)
    if not db:
        return
    if ("expire_old_trash_after" in db.prefs and db.prefs["expire_old_trash_after"] == 7 * 24 * 3600):
        logging.info("Calibre trash expire time already set to 7 days, no need to update.")
        return
    db.prefs["expire_old_trash_after"] = 7 * 24 * 3600
    logging.info("Set calibre trash expire time to 7 days.")


def init_calibre():
    path = options.path_calibre
    if path not in sys.path:
        sys.path.insert(0, path)
    sys.resources_location = options.path_resources
    sys.extensions_location = options.path_plugins
    sys.executables_location = options.path_bin
    sys.system_plugins_location = options.path_system_plugins
    try:
        import calibre  # noqa: F401
    except Exception as e:
        logging.error(traceback.format_exc())
        raise ImportError(
            _("Can not import calibre. Please set the corrent options.\n%s" % e)
        )

    if not options.with_library:
        sys.stderr.write(
            _(
                "No saved library path. Use the --with-library option"
                " to specify the path to the library you want to use."
            )
        )
        sys.stderr.write("\n")
        sys.exit(2)
    else:
        logging.info("Using library path: [%s]" % options.with_library)


def safe_filename(filename):
    return re.sub(r"[\/\\\:\*\?\"\<\>\|]", "_", filename)  # 替换为下划线


# the codes is from calibre source code. just change 'ascii_filename' to 'safe_filename'
def utf8_construct_path_name(book_id, title, author):
    from calibre.db.backend import DB, WINDOWS_RESERVED_NAMES

    book_id = " (%d)" % book_id
    lm = DB.PATH_LIMIT - (len(book_id) // 2) - 2
    lm = lm // 4  # UTF8 is 1~4 char
    author = safe_filename(author)[:lm]
    title = safe_filename(title.lstrip())[:lm].rstrip()
    if not title:
        title = "Unknown"[:lm]
    try:
        while author[-1] in (" ", "."):
            author = author[:-1]
    except IndexError:
        author = ""
    if not author:
        author = _("佚名")
    if author.upper() in WINDOWS_RESERVED_NAMES:
        author += "w"
    return "%s/%s%s" % (author, title, book_id)


def utf8_construct_file_name(book_id, title, author, extlen):
    from calibre.db.backend import DB

    extlen = max(extlen, 14)  # 14 accounts for ORIGINAL_EPUB
    lm = (DB.PATH_LIMIT - extlen - 2) // 2
    lm = lm // 4  # UTF8 is 1~4 char
    if lm < 5:
        raise ValueError("Extension length too long: %d" % extlen)
    author = safe_filename(author)[:lm]
    title = safe_filename(title.lstrip())[:lm].rstrip()
    if not title:
        title = "Unknown"[:lm]
    name = title + " - " + author
    while name.endswith("."):
        name = name[:-1]
    if not name:
        name = safe_filename(_("Unknown"))
    return name


def bind_utf8_book_names(cache):
    cache.backend.construct_path_name = utf8_construct_path_name
    cache.backend.construct_file_name = utf8_construct_file_name
    return


def bind_topdir_book_names(cache):
    old_construct_path_name = cache.backend.construct_path_name

    def new_construct_path_name(*args, **kwargs):
        s = old_construct_path_name(*args, **kwargs)
        ns = s[0] + "/" + s
        logging.debug("new str = %s" % ns)
        return ns

    cache.backend.construct_path_name = new_construct_path_name
    return


def configure_plugins():
    """
      1. 配置 Amazon 插件，将 server 选项设置为 'amazon'
      2. 禁用TXT to TXTZ插件，避免不必要的TXT文件处理
    """
    from calibre.customize.ui import metadata_plugins, metadata_readers, disable_plugin, enable_plugin, can_set_metadata
    try:
        djvu_reader = any("djvu" in p.file_types for p in metadata_readers())
        logging.info("[INIT]DjVu metadata plugins: reader=%s, writer=%s", djvu_reader, can_set_metadata("djvu"))
        for plugin in metadata_plugins({"identify"}):
            if plugin.name == "Amazon.com":
                plugin.prefs["server"] = "amazon"
                break
        if not CONF.get("ENABLE_TXT_TO_TXTZ_PLUGIN", False):
            disable_plugin('TXT to TXTZ')
        else:
            enable_plugin('TXT to TXTZ')
    except Exception as e:
        logging.error("[INIT]Failed to configure plugins: %s" % e)


def make_app():
    auth_db_path = CONF["user_database"]
    logging.info("Revision:: [%s]" % VERSION)
    logging.info("Init library with [%s]" % options.with_library)
    logging.info("Init AuthDB  with [%s]" % auth_db_path)
    logging.info("Init Static  with [%s]" % CONF["resource_path"])
    logging.info("Init HTML    with [%s]" % CONF["html_path"])
    logging.info("Init Nuxtjs  with [%s]" % CONF["nuxt_env_path"])
    banner_width = 90
    border_top = "╭" + "─" * banner_width + "╮"
    border_bottom = "╰" + "─" * banner_width + "╯"
    banner_lines = [
        "",
        border_top,
        "|" + " __  __       ____              _        ".center(banner_width) + "|",
        "|" + "|  \\/  |_   _| __ )  ___   ___ | | _____ ".center(banner_width) + "|",
        "|" + "| |\\/| | | | |  _ \\ / _ \\ / _ \\| |/ / __|".center(banner_width) + "|",
        "|" + "| |  | | |_| | |_) | (_) | (_) |   <\\__ \\".center(banner_width) + "|",
        "|" + "|_|  |_|\\__, |____/ \\___/ \\___/|_|\\_\\___/".center(banner_width) + "|",
        "|" + "        |___/                            ".center(banner_width) + "|",
        "|" + "    ____                                 _____   __                __    _        ".center(banner_width) + "|",
        "|" + "   / __ \\  ____    _  __  ___    ____   / ___/  / /_  __  __  ____/ /   (_)  ____ ".center(banner_width) + "|",
        "|" + "  / /_/ / / __ \\  | |/_/ / _ \\  / __ \\  \\__ \\  / __/ / / / / / __  /   / /  / __ \\".center(banner_width) + "|",
        "|" + " / ____/ / /_/ / _>  <  /  __/ / / / / ___/ / / /_  / /_/ / / /_/ /   / /  / /_/ /".center(banner_width) + "|",
        "|" + "/_/      \\____/ /_/|_|  \\___/ /_/ /_/ /____/  \\__/  \\__,_/  \\__,_/   /_/   \\____/ ".center(banner_width) + "|",
        "|" + (" " * 60 + f"{VERSION}").center(banner_width) + "|",
        border_bottom,
    ]

    if options.update_config:
        logging.info("updating configs ...")
        SettingsSaver().update_nuxtjs_env()
        logging.info("done")
        sys.exit(0)

    # build sql session factory
    StartupState.enter("database")
    engine = create_engine(auth_db_path, **CONF["db_engine_args"])

    if auth_db_path.startswith("sqlite"):
        # Set WAL mode once
        try:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA journal_mode=WAL"))
            logging.info("SQLite journal_mode set to WAL")
        except Exception as e:
            logging.warning(f"Failed to set SQLite WAL mode (falling back to default journal mode): {e}")

        @event.listens_for(engine, "connect")
        def set_sqlite_pragma(db_connection, connection_record):
            cursor = db_connection.cursor()
            try:
                # 60s：扫描导入 Phase1/Phase2 双写并发 + NAS fsync 长尾下，
                # 30s 仍可能误杀正常等待的提交；后台任务写线程卡 60s 可接受，
                # 远好于 OperationalError 丢状态。注意这是本 engine 全部连接
                # （含 Web 请求线程）的行为，极端 wedge 下请求最多慢 60s 而非立刻 500。
                cursor.execute("PRAGMA busy_timeout=60000")
                if CONF.get("SQLITE_RELAXED", False) or perf.lite_on("LITE_SQLITE_RELAXED"):
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA temp_store=MEMORY")
                    cursor.execute("PRAGMA cache_size=-20000")
            except Exception as e:
                logging.warning(f"Failed to set SQLite pragmas: {e}")
            cursor.close()

        # 增加数据异常现场的日志输出
        db_diagnosis.install(engine)

    ScopedSession = scoped_session(sessionmaker(bind=engine, autoflush=True, autocommit=False))
    try:
        models.bind_session(ScopedSession)
        init_social(models.Base, ScopedSession, CONF)
        models.ensure_new_tables(engine)
    except Exception as e:
        logging.error(f"Error binding session: {e}")
        logging.error(traceback.format_exc())
        sys.exit(1)

    if options.syncdb:
        drop_old_table_as_needed(ScopedSession)
        models.user_syncdb(engine)
        logging.info("Create tables into DB")
        sys.exit(0)

    logging.info("\n%s", "\n".join(banner_lines))

    StartupState.enter("calibre")
    try:
        init_calibre()
        config_calibre()
    except Exception as e:
        logging.error(f"Error initializing calibre: {e}")
        logging.error(traceback.format_exc())
        sys.exit(1)

    from calibre import gui2
    from calibre.db.legacy import LibraryDatabase
    if CONF.get("FAST_GET_DATA_AS_DICT", True):
        from webserver.base import calibre_fast

        calibre_fast.install(LibraryDatabase)
    from calibre.utils.date import fromtimestamp
    from calibre.ebooks.metadata.sources.update import patch_plugins

    need_sync_item_to_calibre = False
    try:
        logging.info("Initializing library database...")
        book_db = LibraryDatabase(os.path.expanduser(options.with_library))
        cache = book_db.new_api
        try:
            if hasattr(cache.backend, "prefs"):
                cache.backend.prefs.set("fts_enabled", False)
                logging.info("FTS disabled successfully")
        except Exception as e:
            logging.warning(f"Failed to disable FTS: {e}")

        added_category = add_meta_in_calibre(cache, COLUMN_CATEGORY, "Book Category", "text")
        _ = add_meta_in_calibre(cache, COLUMN_FOLDER, "Book Folder", "text")
        added_phy_count = add_meta_in_calibre(cache, COLUMN_PHY_COUNT, "Physical Book Count", "int")
        added_source = add_meta_in_calibre(cache, COLUMN_BOOK_TYPE, "Book Type", "int")
        added_location = add_meta_in_calibre(cache, COLUMN_LOCATION, "Location", "text")
        _ = add_meta_in_calibre(cache, COLUMN_EXT_LINK, "External Link", "text")
        _ = add_meta_in_calibre(cache, COLUMN_DYNAMIC_COVER, "Dynamic Cover", "int")
        added_translator = add_meta_in_calibre(cache, COLUMN_TRANSLATORS, "Translator", "text")
        # 演播者：有声书的朗读者。中文有声资源 ID3 的 artist 填的是播音员，
        # 不能当作者（见 audios_import.py 的 _extract_audio_metadata），
        # 单独存这一列，作者位留给真作者或佚名。
        add_meta_in_calibre(cache, COLUMN_NARRATOR, "Narrator", "text")
        added_catalog = add_meta_in_calibre(cache, COLUMN_CATALOG, "Catalog", "comments")
        # 作者锁定：用户在界面上手动改过作者的书，自动刮削不再覆盖作者字段。
        # 放在最后，避免影响上面几个列的历史返回值判断。
        add_meta_in_calibre(cache, COLUMN_AUTHOR_LOCKED, "Author Locked", "int")
        if added_source or added_category or added_phy_count or added_location or added_translator or added_catalog:
            need_sync_item_to_calibre = added_source or added_category or added_phy_count
            book_db = LibraryDatabase(os.path.expanduser(options.with_library))
            cache = book_db.new_api
    except Exception as e:
        logging.error(f"Error initializing library database: {e}")
        logging.error(traceback.format_exc())
        sys.exit(1)

    # patch calibre plugins and config amazon plugins
    StartupState.enter("plugins")
    patch_plugins()
    configure_plugins()

    logging.info("Patching calibre book names format...")
    if CONF["BOOK_NAMES_FORMAT"].lower() == "utf8":
        bind_utf8_book_names(cache)
    else:
        bind_topdir_book_names(cache)
    logging.info("Patching calibre GUI requirement...")
    old_must_use_qt = gui2.must_use_qt

    def new_must_use_qt(headless=True):
        try:
            old_must_use_qt(headless)
        except Exception:
            pass

    gui2.must_use_qt = new_must_use_qt

    logging.info("Loading default cover image...")
    path = CONF["resource_path"] + "/calibre/default_cover.jpg"
    if os.path.exists(CUSTOM_COVER_IMAGE):
        path = CUSTOM_COVER_IMAGE
    default_cover = None
    try:
        with open(path, "rb") as cover_file:
            default_cover = cover_file.read()
    except Exception:
        pass

    # Initialize database lock for thread-safe calibre database access
    from webserver.handlers.base import BaseHandler

    BaseHandler.db_lock = threading.RLock()

    app_settings = dict(CONF)
    app_settings.update({
        "log_function": log_request,
        "legacy": book_db,
        "cache": cache,
        "ScopedSession": ScopedSession,
        "build_time": fromtimestamp(os.stat(path).st_mtime),
        "default_cover": default_cover,
        "autoreload": VERSION == "v0.0.1",
        "recommend": RecommendService(
            CalibreFeatureSource(cache), lambda: RecommendConfig.from_conf(CONF), SqlCrowdSource(ScopedSession), SqlProfileSource(ScopedSession)
        ),
    })

    # 是否检查表结构的判定。**注意不要退回 `installed_version != VERSION`**：
    # 那个写法在「版本号没变、但模型加了列」时会跳过整块迁移，r11 就是这样
    # 在 NAS 上报 `no such column: readers.birth_year` 的。详见 helper。
    is_upgrade = should_check_db_structure(CONF, VERSION)
    # 注意：这里刻意不用 f-string 内嵌同种引号（PEP 701，仅 Python 3.12+ 支持），
    # 否则 Python 3.11 及更早版本会报 SyntaxError，本地开发和 CI 都跑不起来。
    _installed = CONF.get("installed_version", "NONE")
    _need = "" if is_upgrade else "no"
    logging.info(
        "The installed version is %s, %s need to check or upgrade table structure.",
        _installed, _need)
    need_sync_item_time = AsyncService().setup(book_db, ScopedSession, need_check_db=is_upgrade)
    if is_upgrade and CONF.get("installed", False):
        logging.info("Need to save the setting for initialized version")
        SettingsSaver().save_extra_settings(CONF)

    StartupState.enter("services")
    logging.info("Now, Running...")
    # WebDAV route is always registered; the handler checks ENABLE_WEBDAV_SERVICE at
    # request time and lazily initialises the WSGI app on first use.
    with substep("import_webdav"):
        from webserver.webdav.handler import WebDAVHandler
    webdav_routes = [
        (r"/books/?(.*)", WebDAVHandler, dict(cache=cache, session=ScopedSession)),
    ]

    # Assemble routes carefully:
    # WebDAV must come before files.routes() because files has a catch-all (r"/(.*)")
    # We need to get routes from handlers module without files, add webdav, then add files
    import importlib
    names = ["assistant", "mcp", "admin", "barcode", "scan", "opds", "book", "mynexus", "book_review", "booklist", "share", "user", "meta", "audio", "toolbox", "sync", "tts", "folder", "reader_dict", "koreader", "reader_group", "transcribe", "book_dedup", "author_norm", "search_index"]
    mods = {}
    for name in names:
        with substep("import_handler:" + name):
            mods[name] = importlib.import_module("webserver.handlers." + name)
    assistant, mcp, admin, barcode, scan, opds, book, mynexus, book_review, booklist, share, user, meta, audio, toolbox, sync, tts, folder, reader_dict, koreader, reader_group, transcribe, book_dedup, author_norm, search_index = (mods[n] for n in names)

    app_routes = []
    app_routes += social_routes.SOCIAL_AUTH_ROUTES
    app_routes += startup_status.routes()
    app_routes += assistant.routes()
    app_routes += mcp.routes()
    app_routes += admin.routes()
    app_routes += barcode.routes()
    app_routes += scan.routes()
    app_routes += opds.routes()
    app_routes += book.routes()
    app_routes += mynexus.routes()
    app_routes += book_review.routes()
    app_routes += booklist.routes()
    app_routes += share.routes()
    app_routes += user.routes()
    app_routes += meta.routes()
    app_routes += audio.routes()
    app_routes += toolbox.routes()
    app_routes += sync.routes()
    app_routes += tts.routes()
    app_routes += folder.routes()
    app_routes += reader_dict.routes()
    app_routes += reader_group.routes()
    app_routes += transcribe.routes()
    app_routes += book_dedup.routes()
    # 4.6.0-9 作者归一化管理接口（体检/别名表/预览/锁定）
    app_routes += author_norm.routes()
    # 中文检索索引：状态查询 + 手动重建（搜索接口本身保持不变）
    app_routes += search_index.routes()
    app_routes += koreader.routes()

    # Podcast routes are always registered; each handler calls check_podcast_enabled()
    # at request time, so toggling ENABLE_PODCAST_SERVICE takes effect without restart.
    with substep("import_podcast"):
        from webserver.handlers.podcast import routes as podcast_route_func
    app_routes += podcast_route_func()

    # WAP routes: server-side rendered HTML pages for Kindle browsers.
    # Must be registered BEFORE static_files.routes() so they take precedence
    # over the Vue SPA assets served at /wap/*.
    with substep("import_wap"):
        from webserver.handlers import wap as wap_handler
    app_routes += wap_handler.routes()

    # Insert WebDAV routes BEFORE files.routes()
    app_routes += webdav_routes
    # files.routes() contains catch-all r"/(.*)" so must be last
    app_routes += static_files.routes()

    with substep("build_application"):
        app = web.Application(app_routes, **app_settings)
    app._engine = engine

    # Start background service
    with substep("bookbarn_daily"):
        BookBarnService().get_daily_books()

    # Init the resources
    with substep("resource_service"):
        resources_service = ResourceService()

    # Sync authors as needed
    if CONF.get("ENABLE_AUTHOR_INFO", False) and CONF.get("ENABLE_BOOKBARN", False):
        BookBarnService().sync_author_list()

    # Automatically start AI Assistant if configured
    if CONF.get("AI_DEEPSEEK_API_KEY"):
        from webserver.handlers.assistant import AssistantWebSocketHandler
        from webserver.assistant.ai_assistant_agent import AIAssistantMCPAgent

        def init_ai_agent():
            agent = AIAssistantMCPAgent()
            AssistantWebSocketHandler._agent = agent
            # Note: initialization will happen on first connection or we can trigger it here
            # But deepseek_agent.initialize() is async, so we need to run it in the ioloop
            tornado.ioloop.IOLoop.current().spawn_callback(agent.initialize)

        init_ai_agent()

    # Start item create_time sync service if needed
    if need_sync_item_time:
        logging.info("Starting item create_time sync service")
        ItemSyncService().sync_item_create_time()
    if need_sync_item_to_calibre:
        logging.info("Starting item to calibre sync service")
        ItemSyncService().sync_items_to_calibre()

    # Start performance profiling service if enabled
    from webserver.constants import ENABLE_PROFILE

    if CONF.get(ENABLE_PROFILE) is True:
        from webserver.services.profile_service import get_profile_service
        profile_service = get_profile_service()
        profile_service.start()

    if CONF.get("CALIBRE_CACHE_CLEAN_ENABLED", True):
        from webserver.services.calibre_cache_clean import get_cache_clean_service
        cache_clean_service = get_cache_clean_service()
        cache_clean_service.setup(cache)
        cache_clean_service.start()

    if CONF.get("IMPORT_BY_INOTIFY", False):
        from webserver.services.monitor_service import get_monitor_service
        with substep("monitor_service"):
            get_monitor_service().start()

    from webserver.services.reading_stats_service import ReadingStatsService
    with substep("reading_stats"):
        ReadingStatsService.start()
    import atexit
    # best-effort：覆盖正常退出/SIGINT，不保证 SIGKILL/supervisor 强杀场景，
    # 见 document/Reading_Stats_Design.md §11.4
    atexit.register(ReadingStatsService.stop)

    from webserver.services.book_visit_service import BookVisitService
    with substep("book_visit"):
        BookVisitService.start()
    atexit.register(BookVisitService.stop)

    from webserver.services.sync_service import MyReaderSyncService
    with substep("sync_service"):
        MyReaderSyncService.start()
    atexit.register(MyReaderSyncService.stop)

    return app


def get_upload_size():
    n = 1
    s = CONF["MAX_UPLOAD_SIZE"].lower().strip()
    if s.endswith("k") or s.endswith("kb"):
        n = 1024
        s = s.split("k")[0]
    elif s.endswith("m") or s.endswith("mb"):
        n = 1024 * 1024
        s = s.split("m")[0]
    elif s.endswith("g") or s.endswith("gb"):
        n = 1024 * 1024 * 1024
        s = s.split("g")[0]
    s = s.strip()
    return int(s) * n


def setup_logging():
    logger = logging.getLogger()
    log_level = logging.DEBUG if CONF.get("LOG_LEVEL_DEBUG", False) or VERSION == "v0.0.1" else logging.INFO
    if options.log_file_prefix:
        # remove tornado default file handler to avoid duplicate logs
        logger.handlers = [h for h in logger.handlers if not isinstance(h, logging.FileHandler)]
        file_handler = RotatingFileHandler(options.log_file_prefix, maxBytes=5 * 1024 * 1024, backupCount=5)
        file_handler.setLevel(log_level)
        file_handler.setFormatter(tornado.log.LogFormatter())
        logger.addHandler(file_handler)
    logger.setLevel(log_level)
    logging.debug("**Debug logging is enabled.**")


def log_request(handler):
    status = handler.get_status()
    level = logging.INFO if status < 400 else logging.WARNING if status < 500 or status == 503 else logging.ERROR
    cost_ms = 1000.0 * handler.request.request_time()
    if CONF.get("PERF_MONITOR", False):
        PerfMonitor.instance().record_request(handler.request.method, handler.request.path, cost_ms)
    logging.log(level, f"[{status}][{cost_ms:.2f}ms][{handler.request.method}][{handler.request.uri}]({handler.request.remote_ip}){'' if cost_ms < 1000 else '[x]'}")


def main():
    threading.current_thread().name = "mybooks"
    tornado.options.parse_command_line()
    setup_logging()
    logging.debug("[thread] main thread renamed to %s", threading.current_thread().name)

    # 配置异步 HTTP 客户端的最大连接数
    AsyncHTTPClient.configure(None, max_clients=200)

    from webserver.services.sync_service import MyReaderSyncService
    need_sync_migration = CONF.get("installed", False) and MyReaderSyncService.is_enabled() and not CONF.get("SYNC_LEGACY_MIGRATION_DONE", False)

    # 启动全程先由临时状态服务占住端口应答进度，就绪后把同一组监听 socket 交给正式服务
    sockets = None
    status_server = None
    if not (options.syncdb or options.update_config):
        sockets = startup_status.bind_service_sockets(options.port, options.host)
    if sockets:
        steps = ["database", "calibre", "plugins"]
        # 与上面 is_upgrade 用同一个判定，否则会出现「状态页不显示迁移步骤，
        # 但迁移其实在跑」——启动页停在 90% 不动，用户以为卡死就重启。
        if should_check_db_structure(CONF, VERSION):
            steps += list(startup_status.UPGRADE_STEPS)
        steps.append("services")
        if need_sync_migration:
            steps.append("sync_migration")
        StartupState.plan(steps)
        status_server = startup_status.StartupStatusServer(sockets)
        status_server.start()

    try:
        try:
            app = make_app()
        except Exception as e:
            logging.error(f"Error making app: {e}")
            logging.error(traceback.format_exc())
            sys.exit(1)

        if need_sync_migration:
            # 不停机迁移旧版 <MYREADER_SYNC_PATH>/<uid>/<book_hash>/{kind}.json 文件到
            # reading_records 表，见 plan/Social_Reading_Plan.md §7.1。只在真正的服务器启动
            # 路径上跑一次（不在 make_app() 里，避免测试/工具脚本调用 make_app() 时意外扫描
            # 本机磁盘上的旧同步目录）；扫描本身对已迁移完的用户是 O(1) 的空目录判断。
            StartupState.enter("sync_migration")
            try:
                MyReaderSyncService.migrate_legacy_data()
            except Exception:
                logging.error("[sync] legacy data migration failed, will retry on next startup", exc_info=True)
    finally:
        StartupState.finish()
        if status_server:
            status_server.stop()

    logging.info("Starting server...")
    logging.debug("Max upload size set to: %d bytes", get_upload_size())
    http_server = tornado.httpserver.HTTPServer(app, xheaders=True, max_buffer_size=get_upload_size())
    if sockets:
        http_server.add_sockets(sockets)
    else:
        http_server.listen(options.port, options.host)
    tornado.ioloop.PeriodicCallback(lambda: models.Message.cleanup_old_messages(), 24 * 3600 * 1000).start()

    # 预热「有音频的书」缓存：后台线程扫一遍库，首个列表请求就不用等全库 listdir。
    # 扫描失败不影响启动（缓存保持空集，后续事件会再触发刷新）。
    try:
        from webserver.handlers.audio import AudioBooksCache
        AudioBooksCache.async_update()
    except Exception:
        logging.warning("Audio cache prewarm failed", exc_info=True)

    # 检索索引：缺失/过期时后台重建；之后每 5 分钟检查一次版本
    try:
        from webserver.services.search_index import get_search_index
        get_search_index().start_background_refresh()
    except Exception:
        logging.warning("Search index warmup failed", exc_info=True)

    switch_ms = float(CONF.get("GIL_SWITCH_INTERVAL_MS", 0) or 0)
    if switch_ms > 0:
        sys.setswitchinterval(switch_ms / 1000.0)
        logging.info("GIL switch interval set to %s ms", switch_ms)
    if CONF.get("WARMUP_ENABLE", True):
        from webserver.handlers.base import BaseHandler

        settings = app.settings
        warmup.start(
            settings["legacy"], settings["cache"], BaseHandler.db_lock, settings["recommend"] if CONF.get("RECOMMEND_ENABLE", True) else None, settings["ScopedSession"],
            300 if perf.lite_on("LITE_BG_SLOWER") else int(CONF.get("WARMUP_DELAY_SEC", 10))
        )
    if perf.lite_on("LITE_GC_TUNE"):
        gc.collect()
        gc.freeze()
        gc.set_threshold(50000, 20, 100)
    perf.apply_logging()
    logging.info("[STARTUP-TIMING] step=listening since_import_ms=%.0f", (time.perf_counter() - StartupState.t0) * 1000)
    if PerfMonitor.instance().enabled:
        PerfMonitor.instance().start(int(CONF["PERF_STALL_MS"]))
    tornado.ioloop.IOLoop.instance().start()

    from flask.ext.sqlalchemy import _EngineDebuggingSignalEvents
    _EngineDebuggingSignalEvents(app._engine, app.import_name).register()


if __name__ == "__main__":
    sys.path.append(os.path.dirname(__file__))
    sys.exit(main())
