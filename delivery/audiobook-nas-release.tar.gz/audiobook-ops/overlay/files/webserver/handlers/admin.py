#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import datetime
import logging
import os
import re
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import traceback
import uuid
from webserver.i18n import _, normalize_language
from sqlalchemy import func

import tornado
import tornado.ioloop

from webserver import loader, utils
from webserver.services.autofill import AutoFillService
from webserver.services.ai_fillinfo import AIFillInfoService
from webserver.services.batch_convert import BatchConvertService
from webserver.services.batch_title_sort import BatchTitleSortUpdateService
from webserver.services.metadata_update import MetaDataUpdateService
from webserver.services.batch_generate_cover import DynamicCoverUpdateService
from webserver.services.resource_service import ResourceService
from webserver.services.save_meta_to_files import SaveMetaToFilesService
from webserver.services.mail import MailService
from webserver.services.book_barn import BookBarnClient, BookBarnService
from webserver.services.download_quota_service import (
    DownloadQuotaService,
    DOWNLOAD_QUOTA_FOLLOW_GLOBAL,
)
from webserver.services.perf_monitor import PerfMonitor
from webserver.services.background_service import BackgroundService, BackgroundTask
from webserver.services.book_search import BookSearch
from webserver.handlers.base import BaseHandler, auth, js, is_admin
from webserver import perf
from webserver.models import Reader, Item, Authors, Reading, BookReview, Message
from webserver.services.book_review_service import BookReviewService
from webserver.base.formatter import SimpleBookFormatter
from webserver.base.setting_saver import ADMIN_SETTING_KEYS, SettingsSaver
from webserver.base.homepage import get_homepage_config, normalize_homepage
from webserver.base.sidebar import SIDEBAR_DEFAULT_ITEMS, SIDEBAR_ITEMS_MIGRATED_KEY, get_sidebar_items
from webserver.base.trash_manager import TrashManager
from webserver.version import VERSION
from webserver.handlers.audio import AudioUtils
from webserver.handlers import reader_dict
from webserver.assistant.book_ai_client import BookAIClient
from webserver.constants import (
    CALIBRE_COLUMN_BOOK_TYPE,
    BOOK_TYPE_PHYSICAL,
    BOOK_TYPE_EBOOK,
    ENABLE_OPDS_SERVICE,
    AUTO_FILL_META,
)
from webserver.i18n import apply_localized_default_settings

CONF = loader.get_settings()
USER_UPDATE_TS_MAP = {}
ENABLE_VIP_QUOTA_KEY = "ENABLE_VIP_QUOTA"
IMPORT_BY_INOTIFY = "IMPORT_BY_INOTIFY"
DEFAULT_META_SOURCES = ["douban", "baidu", "xinhua"]
LOG_PATH = "/data/log/mybooks.log"


class AdminUsers(BaseHandler):
    @js
    @auth
    def get(self):
        if not self.admin_user:
            return {"err": "permission.not_admin", "msg": _("当前用户非管理员")}

        num = max(10, int(self.get_argument("num", 20)))
        page = max(0, int(self.get_argument("page", 1)) - 1)
        sort = self.get_argument("sort", "access_time")
        desc = self.get_argument("desc", "desc")
        logging.debug("num=%d, page=%d, sort=%s, desc=%s" % (num, page, sort, desc))

        push_count_subq = None
        if sort == "push_count":
            push_count_subq = (
                self.sqlite_session.query(
                    Reading.reader_id.label("reader_id"),
                    func.count(Reading.id).label("push_cnt"),
                )
                .filter(Reading.action == Reading.ACTION_PUSH)
                .group_by(Reading.reader_id)
                .subquery()
            )

        f = {
            "id": Reader.id,
            "access_time": Reader.access_time,
            "create_time": Reader.create_time,
            "update_time": Reader.update_time,
            "username": Reader.username,
            "total_reading_seconds": Reader.total_reading_seconds,
            "download_count": Reader.download_count,
            "push_count": (
                func.coalesce(push_count_subq.c.push_cnt, 0)
                if push_count_subq is not None
                else None
            ),
        }.get(sort, Reader.id)
        if desc == "false":
            f = f.asc()
        else:
            f = f.desc()

        enable_vip_quota = CONF.get(ENABLE_VIP_QUOTA_KEY, False)
        enable_download_quota = CONF.get("ENABLE_DOWNLOAD_QUOTA", False)
        query = self.sqlite_session.query(Reader)
        if push_count_subq is not None:
            query = query.outerjoin(
                push_count_subq, Reader.id == push_count_subq.c.reader_id
            )
        query = query.order_by(f)
        total = query.count()
        start = page * num
        page_users = query.limit(num).offset(start).all()
        user_ids = [u.id for u in page_users]
        reading_counts = {}
        if user_ids:
            rows = (
                self.sqlite_session.query(
                    Reading.reader_id, Reading.action, func.count(Reading.id)
                )
                .filter(
                    Reading.reader_id.in_(user_ids),
                    Reading.action.in_([Reading.ACTION_READ, Reading.ACTION_PUSH]),
                )
                .group_by(Reading.reader_id, Reading.action)
                .all()
            )
            reading_counts = {
                (reader_id, action): cnt for reader_id, action, cnt in rows
            }
        items = []
        user_config = {
            "allow_read_range_setting": CONF.get("ALLOW_READ_RANGE_SETTING", False),
            "enable_download_quota": enable_download_quota,
        }
        for user in page_users:
            has_social_account = (
                hasattr(user, "social_auth") and user.social_auth.count() > 0
            )
            user_provider = (
                user.social_auth[0].provider if has_social_account else "register"
            )
            d = {
                "id": user.id,
                "username": user.username,
                "name": user.name,
                "email": user.email,
                "avatar": user.avatar,
                "is_active": user.is_active(),
                "is_admin": user.is_admin(),
                "extra": dict(user.extra),
                "provider": user_provider,
                "create_time": (
                    user.create_time.strftime("%Y-%m-%d %H:%M:%S")
                    if user.create_time
                    else "N/A"
                ),
                "update_time": (
                    user.update_time.strftime("%Y-%m-%d %H:%M:%S")
                    if user.update_time
                    else "N/A"
                ),
                "access_time": (
                    user.access_time.strftime("%Y-%m-%d %H:%M:%S")
                    if user.access_time
                    else "N/A"
                ),
                "read_limit": user.read_limit or 0,
                "limit_categories": user.limit_categories or "",
                "limit_tags": user.limit_tags or "",
                "read_count": reading_counts.get((user.id, Reading.ACTION_READ), 0),
                "push_count": reading_counts.get((user.id, Reading.ACTION_PUSH), 0),
                "download_count": user.download_count or 0,
                "total_reading_seconds": user.total_reading_seconds or 0,
                "allow_review": user.allow_review,
                # r11：注册必填出生年份，年龄由年份实时算出（不再落库整数岁，
                # 否则跨年不会自然长大）。birth_year=0 表示历史用户未填。
                "birth_year": user.birth_year or 0,
                "age": user.age or 0,
            }
            if enable_vip_quota:
                d["vipquota"] = user.vipquota or 0
                d["vip_expire"] = (
                    user.vipexpire.strftime("%Y-%m-%d") if user.vipexpire else ""
                )
            if enable_download_quota:
                usage = DownloadQuotaService.get_usage(user)
                d["download_quota_used"] = usage.used
                d["download_quota_limit"] = 0 if user.is_admin() else usage.quota
                d["download_daily_quota"] = (user.extra.get("downloads") or {}).get(
                    "daily_quota", DOWNLOAD_QUOTA_FOLLOW_GLOBAL
                )
            for attr in dir(user):
                if attr.startswith("can_"):
                    d[attr] = getattr(user, attr)()
            need_update = False
            ts = USER_UPDATE_TS_MAP.get(user.id, 0)
            if not ts or (datetime.datetime.now() - ts).total_seconds() > 3600:
                need_update = True
                USER_UPDATE_TS_MAP[user.id] = datetime.datetime.now()
            if need_update or "upload_history_count" not in user.extra:
                d["extra"]["upload_history_count"] = self.get_user_upload_cnt(user.id)
            else:
                d["extra"]["upload_history_count"] = user.extra.get(
                    "upload_history_count", 0
                )
            items.append(d)
        return {
            "err": "ok",
            "users": {"items": items, "total": total},
            "settings": user_config,
        }

    @js
    @auth
    def post(self):
        if not self.admin_user:
            return {"err": "permission.not_admin", "msg": _("当前用户非管理员")}
        data = tornado.escape.json_decode(self.request.body)
        uid = data.get("id", None)
        if not uid:
            return {"err": "params.invalid", "msg": _("参数错误")}
        del data["id"]
        if not data:
            return {"err": "params.fields.invalid", "msg": _("用户配置项参数错误")}
        user = self.sqlite_session.query(Reader).filter(Reader.id == uid).first()
        if not user:
            return {"err": "params.user.not_exist", "msg": _("用户ID错误")}

        # §管理员不接受「限制类」设置§（r9）管理员是能管理别人的人，不该反过来
        # 被禁言、限阅读范围、限下载配额、停用账号。前端菜单对这些行已经不显示，
        # 这里再拦一道：直接构造请求也改不动。
        # 只放行「账号凭据」两项：username / password。
        # 注意 admin / delete 这两个键不在白名单里，会被下面这条拦下并单独
        # 给出更明确的提示——否则「取消管理员」和「删除管理员」只会得到一句
        # 含糊的「不能做限制类设置」，排查起来像权限系统坏了。
        ADMIN_ALLOWED_FIELDS = {"username", "password"}
        if user.is_admin() and self.user_id() != user.id:
            if "admin" in data and not data["admin"]:
                return {
                    "err": "params.user.invalid",
                    "msg": _("不允许取消其他管理员的管理员权限"),
                }
            if "delete" in data:
                return {
                    "err": "params.user.invalid",
                    "msg": _("不允许删除管理员账号，请先取消其管理员权限"),
                }
            bad = [k for k in data if k not in ADMIN_ALLOWED_FIELDS]
            if bad:
                return {
                    "err": "params.user.invalid",
                    "msg": _("管理员账号只允许修改用户名和密码，不能对其做限制类设置"),
                }
        if "active" in data:
            user.active = data["active"]

        if "admin" in data:
            user.admin = data["admin"]

        if "allow_review" in data:
            user.allow_review = bool(data["allow_review"])

        # §出生年份（r11）§ 注册时填错的允许管理员纠正；0 表示「未填」，
        # 老用户补填也走这里。范围校验复用 Reader.parse_birth_year。
        # 兼容：若前端/第三方仍按老字段名 age 传整数岁，换算成出生年份再落库，
        # 避免升级瞬间「改年龄」全部报参数错误。
        if "birth_year" in data or "age" in data:
            if "birth_year" in data:
                birth_year, code, msg = Reader.parse_birth_year(data["birth_year"])
            else:
                age, code, msg = Reader.parse_age_to_birth_year(data["age"])
                birth_year = age
            if code != "ok":
                return {"err": code, "msg": msg}
            user.birth_year = birth_year

        if user.admin is False and self.user_id() == user.id:
            return {
                "err": "params.user.invalid",
                "msg": _("不允许取消自己的管理员权限"),
            }

        # §改名§（r9）与密码同属「账号凭据」，只认证不认设置项。
        if "username" in data:
            old_username = user.username
            new_username = (data["username"] or "").strip().lower()
            if not new_username:
                return {"err": "params.username.invalid", "msg": _("用户名不能为空")}
            if (
                len(new_username) < 3
                or len(new_username) > 20
                or not re.match(Reader.RE_USERNAME, new_username)
            ):
                return {
                    "err": "params.username.invalid",
                    "msg": _("用户名无效：3~20 位，以小写字母开头，只能包含小写字母、数字和下划线"),
                }
            if new_username != user.username:
                exists = (
                    self.sqlite_session.query(Reader.id)
                    .filter(Reader.username == new_username)
                    .first()
                )
                if exists:
                    return {"err": "params.username.exist", "msg": _("用户名已被使用")}
                # §同步 nickname§ 新建用户时 name 默认等于 username；若用户从未
                # 单独改过昵称（两者仍相同），改名时一起改，否则「用户名变了、
                # 显示的昵称还是旧名」。改过昵称的尊重用户自己的设置，不动。
                if not user.name or user.name == user.username:
                    user.name = new_username
                user.username = new_username
                logging.info(
                    "[ADMIN] username renamed: id=%s %s -> %s by %s",
                    user.id, old_username, new_username,
                    self._cached_username,
                )

        if data.get("delete", "") == user.username:
            if self.user_id() == user.id:
                return {"err": "params.user.invalid", "msg": _("不允许删除自己")}

            self.sqlite_session.query(Reader).filter(Reader.id == user.id).delete()
            self.sqlite_session.commit()
            return {"err": "ok", "msg": _("删除成功")}

        if "read_limit" in data:
            rl = int(data["read_limit"])
            if rl not in (0, 1, 2):
                return {
                    "err": "params.read_limit.invalid",
                    "msg": _("阅读限制参数不对"),
                }
            user.read_limit = rl
        if "limit_categories" in data:
            user.limit_categories = data["limit_categories"]
        if "limit_tags" in data:
            user.limit_tags = data["limit_tags"]

        if "download_daily_quota" in data:
            try:
                daily_quota = int(data["download_daily_quota"])
            except (TypeError, ValueError):
                return {
                    "err": "params.download_daily_quota.invalid",
                    "msg": _("下载配额参数不对"),
                }
            if daily_quota < DOWNLOAD_QUOTA_FOLLOW_GLOBAL or daily_quota > 1000:
                return {
                    "err": "params.download_daily_quota.invalid",
                    "msg": _("下载配额参数不对，需为-1~1000之间的整数"),
                }
            downloads = dict(user.extra.get("downloads") or {})
            downloads["daily_quota"] = daily_quota
            user.extra["downloads"] = downloads

        if "password" in data:
            new_password = (data["password"] or "").strip()
            ok, code, msg = Reader.check_password_strength(new_password)
            if not ok:
                return {"err": code, "msg": msg}
            user.set_secure_password(new_password)

        p = data.get("permission", "")
        if not isinstance(p, str):
            return {"err": "params.permission.invalid", "msg": _("权限参数不对")}
        if p:
            user.set_permission(p)
        user.save()
        return {"err": "ok"}


class AdminBookReviews(BaseHandler):
    """管理员"用户评论"管理页：分页列出所有评论，支持按状态过滤，以及通过/屏蔽/恢复操作。
    见 plan/Social_Reading_Plan.md §2.6。"""

    @js
    @is_admin
    def get(self):
        status = self.get_argument("status", "") or None
        if status is not None and status not in (
            BookReview.STATUS_PENDING,
            BookReview.STATUS_APPROVED,
            BookReview.STATUS_HIDDEN,
        ):
            return {"err": "params.invalid", "msg": _("非法的 status 参数")}
        try:
            page = max(1, int(self.get_argument("page", 1)))
            page_size = min(100, max(1, int(self.get_argument("page_size", 20))))
        except (TypeError, ValueError):
            return {"err": "params.invalid", "msg": _("分页参数错误")}

        rows, total = BookReviewService.list_for_admin(
            self.sqlite_session, status=status, page=page, page_size=page_size
        )
        reader_ids = {r.reader_id for r in rows}
        book_ids = list({r.book_id for r in rows})
        readers = {}
        if reader_ids:
            readers = {
                u.id: u
                for u in self.sqlite_session.query(Reader)
                .filter(Reader.id.in_(reader_ids))
                .all()
            }
        books = {b["id"]: b for b in self.get_books(ids=book_ids)} if book_ids else {}

        items = []
        for row in rows:
            reader = readers.get(row.reader_id)
            book = books.get(row.book_id)
            items.append(
                {
                    "id": row.id,
                    "book_id": row.book_id,
                    "book_title": book.get("title", "") if book else "",
                    "reader_id": row.reader_id,
                    "username": reader.username if reader else "",
                    "rating": row.rating,
                    "comment": row.comment or "",
                    "status": row.status,
                    "update_time": (
                        row.update_time.strftime("%Y-%m-%d %H:%M:%S")
                        if row.update_time
                        else ""
                    ),
                }
            )
        return {
            "err": "ok",
            "total": total,
            "page": page,
            "page_size": page_size,
            "reviews": items,
        }

    @js
    @is_admin
    def post(self):
        data = tornado.escape.json_decode(self.request.body or b"{}")
        review_id = data.get("id")
        action = data.get("action")
        if not review_id or action not in ("approve", "hide", "restore", "delete"):
            return {"err": "params.invalid", "msg": _("参数错误")}
        if action == "delete":
            # 物理删除，见 plan §2.4c：不同于"隐藏"，删除后不可恢复、也不会再出现在任何列表里
            if not BookReviewService.hard_delete(self.sqlite_session, int(review_id)):
                return {"err": "params.invalid", "msg": _("评论不存在")}
            return {"err": "ok", "msg": _("已删除")}
        row = BookReviewService.moderate(self.sqlite_session, int(review_id), action)
        if row is None:
            return {"err": "params.invalid", "msg": _("评论不存在")}
        return {"err": "ok", "msg": _("操作成功")}


class AdminTestMail(BaseHandler):
    @js
    @auth
    def post(self):
        mail_enc = self.get_argument("smtp_encryption")
        mail_server = self.get_argument("smtp_server")
        mail_username = self.get_argument("smtp_username")
        mail_password = self.get_argument("smtp_password")

        mail_from = mail_username
        mail_to = mail_username
        mail_subject = _("Calibre功能验证邮件")
        mail_body = _("这是一封测试邮件，验证邮件参数是否配置正确。")

        try:
            MailService().do_send_mail(
                mail_from,
                mail_to,
                mail_subject,
                mail_body,
                relay=mail_server,
                username=mail_username,
                password=mail_password,
                encryption=mail_enc,
            )
            return {"err": "ok", "msg": _("发送成功")}
        except Exception as e:
            logging.error(traceback.format_exc())
            return {"err": "email.server_error", "msg": str(e)}


class AdminOwnerMode(BaseHandler):
    @auth
    def get(self):
        user_id = self.get_argument("user_id", None)
        if user_id and self.is_admin():
            self.set_secure_cookie("admin_id", self.user_id())
            self.set_secure_cookie("user_id", user_id)
        self.redirect("/", 302)


class AdminSettings(BaseHandler):
    @js
    @auth
    def get(self):
        if not self.admin_user:
            return {"err": "permission", "msg": _("无权访问此接口")}

        hour_ = int(CONF.get("BOOKBARN_COLLECTION_HOUR", 24))
        if hour_ >= 24 or hour_ < 0:
            CONF["BOOKBARN_COLLECTION_HOUR"] = 3
        if CONF.get("ENABLE_RECEIVING_BOOKS", None) is None:
            CONF["ENABLE_RECEIVING_BOOKS"] = CONF.get("ENABLE_BOOKBARN", False)
        if CONF.get("ENABLE_OPDS_SERVICE", None) is None:
            CONF["ENABLE_OPDS_SERVICE"] = True

        if CONF.get("MAIN_PAGE_RANDOM_COUNT", -1) == -1:
            CONF["MAIN_PAGE_RANDOM_COUNT"] = 12
        if CONF.get("MAIN_PAGE_RECENT_COUNT", -1) == -1:
            CONF["MAIN_PAGE_RECENT_COUNT"] = 12
        if CONF.get("INDEX_PAGE_TYPE", -1) == -1:
            CONF["INDEX_PAGE_TYPE"] = (
                "index"  # 默认首页, 可能的值包括index, all, categories三类
            )
        if CONF.get("DEFAULT_PAGE_SIZE", -1) == -1:
            CONF["DEFAULT_PAGE_SIZE"] = 60  # 默认每页显示60本书

        if not CONF.get("SIDEBAR_ITEMS", []):
            # 默认列表的唯一权威定义在 webserver/base/sidebar.py（下发给前端时同一份归一化）
            CONF["SIDEBAR_ITEMS"] = list(SIDEBAR_DEFAULT_ITEMS)

        # 与首页渲染共用同一套归一化：auto.py 被手改成非 dict/空值时也会回退旧开关，
        # 否则设置页显示"全部可见"，管理员保存任意设置就会被静默改写首页行为。
        homepage_config = get_homepage_config()

        CONF["site_icon"] = "favicon_0"  # default icon, means use current favicon.ico
        CONF["META_ALL_SOURCES"] = BookSearch.all_sources()

        if "STANDALONE" not in CONF:
            CONF["STANDALONE"] = False

        sns = [
            {"value": "qq", "text": "QQ", "link": "https://connect.qq.com/"},
            {
                "value": "github",
                "text": "Github",
                "link": "https://github.com/settings/applications/new",
            },
            {
                "value": "weibo",
                "text": "微博",
                "link": "http://open.weibo.com/developers",
            },
            {
                "value": "weixin",
                "text": "微信",
                "link": "https://developers.weixin.qq.com/doc/offiaccount/OA_Web_Apps/Wechat_webpage_authorization.html",
            },
        ]
        settings = dict(CONF)
        settings["HOMEPAGE_CONFIG"] = homepage_config
        # 与 /user/info 同一套读取期归一化：迁移标记未置位时，升级前保存过的旧默认列表
        # 缺 authors/friends/booklists，设置页必须显示补齐后的结果，否则管理员一保存就把
        # 陈旧缺项固化下来；标记已置位（管理员保存过设置页）则 stored 列表即权威，原样返回。
        # 只改返回给前端的副本，不回写 CONF，也不改写用户存的配置。
        settings["SIDEBAR_ITEMS"] = get_sidebar_items(CONF)
        return {"err": "ok", "settings": settings, "sns": sns, "site_url": self.site_url}

    @js
    @auth
    def post(self):
        if not self.admin_user:
            return {"err": "permission.not_admin", "msg": _("当前用户非管理员")}

        data = tornado.escape.json_decode(self.request.body)
        KEYS = list(ADMIN_SETTING_KEYS)

        current_icon = CONF.get(
            "site_icon", "favicon_0"
        )  # favicon_0 means use current icon
        current_vip_quota = CONF.get(ENABLE_VIP_QUOTA_KEY, False)
        args = loader.SettingsLoader()
        args.clear()

        for key, val in data.items():
            if key.startswith("SOCIAL_AUTH"):
                if key.endswith("_KEY") or key.endswith("_SECRET"):
                    if not re.match(r"^[A-Za-z0-9_]+$", key):
                        continue
                    args[key] = val
            elif key in KEYS:
                args[key] = val

        # Check and set the favicon
        if "site_icon" not in args or not args["site_icon"]:
            args["site_icon"] = "favicon_0"

        if ENABLE_VIP_QUOTA_KEY not in args:
            args[ENABLE_VIP_QUOTA_KEY] = current_vip_quota
        if ENABLE_OPDS_SERVICE not in args:
            args[ENABLE_OPDS_SERVICE] = CONF.get(ENABLE_OPDS_SERVICE, True)
        if args.get(IMPORT_BY_INOTIFY, False):
            # 如果启用基于 inotify 的文件导入，不能默认删除文件
            args["REMOVE_IMPORTED_FILE"] = False

        if "READER_MYDICTS" in args:
            args["READER_MYDICTS"] = reader_dict.sanitize_mydicts(args["READER_MYDICTS"])
        perf.sanitize(args, CONF)

        args["META_ALL_SOURCES"] = BookSearch.all_sources()
        if "META_SELECTED_SOURCES" not in args:
            args["META_SELECTED_SOURCES"] = DEFAULT_META_SOURCES

        if args["site_icon"] != "favicon_0" and args["site_icon"] != current_icon:
            new_icon_path = CONF["static_path"] + "/logo/" + args["site_icon"] + ".ico"
            logging.info(_("Set new favicon: %s") % new_icon_path)
            if os.path.exists(new_icon_path):
                # Copy the new icon to the static directory
                static_icon_path = CONF["static_path"] + "/logo/" + "/favicon.ico"
                try:
                    shutil.copy(new_icon_path, static_icon_path)
                except Exception as e:
                    logging.info("Error: %s", str(e))
        # 网站默认访问链接：留空表示按当前访问地址生成分享链接/二维码；
        # 填了就必须是合法的 http/https 地址，否则前端会拼出坏链接且肉眼难发现
        if "SITE_URL" in args:
            site_url_raw = str(args["SITE_URL"] or "").strip()
            site_url = utils.normalize_site_url(site_url_raw)
            if site_url_raw and not site_url:
                return {
                    "err": "params.site_url.invalid",
                    "msg": _(
                        "网站默认访问链接无效，需以 http:// 或 https:// 开头，且不能包含空格"
                    ),
                }
            args["SITE_URL"] = site_url
        # 系统时区：auto 或 IANA 时区名。只做形态校验、不查库——名字确实不存在时
        # webserver/site_time.py 会在运行时回退到站点语言默认并打 warning（精简镜像缺
        # tzdata 时合法名字也查不到，在这里拦会把对的也拒了）；这里挡的是空格、引号、
        # 超长这类脏值。
        if "site_timezone" in args:
            tz = str(args["site_timezone"] or "").strip()
            if tz and not utils.is_timezone_name(tz):
                return {
                    "err": "params.site_timezone.invalid",
                    "msg": _("系统时区无效，需填写 auto 或 IANA 时区名（如 Asia/Shanghai）"),
                }
            args["site_timezone"] = tz
        if "HOMEPAGE_CONFIG" in args:
            args["HOMEPAGE_CONFIG"] = normalize_homepage(args["HOMEPAGE_CONFIG"])
            homepage_hidden = set(args["HOMEPAGE_CONFIG"]["hidden"])
            args["ENABLE_HOMEPAGE_READING_STATS"] = "readingStats" not in homepage_hidden
            args["ENABLE_HOMEPAGE_READING_BOOKS"] = "index.myReading" not in homepage_hidden
            args["ENABLE_HOMEPAGE_BOOKLISTS"] = "index.booklistRecommendation" not in homepage_hidden
            if "index.randomRecommendation" not in homepage_hidden:
                fallback_random = CONF.get("MAIN_PAGE_RANDOM_COUNT", 12) or 12
                try:
                    if int(args.get("MAIN_PAGE_RANDOM_COUNT", fallback_random) or 0) <= 0:
                        args["MAIN_PAGE_RANDOM_COUNT"] = 12
                except (TypeError, ValueError):
                    args["MAIN_PAGE_RANDOM_COUNT"] = 12
        # Check the douban_apikey if only number, letters, _ or -, and length <=48
        if "douban_apikey" in args:
            apikey = args["douban_apikey"]
            if apikey and not re.match(r"^[a-zA-Z0-9_-]{1,48}$", apikey):
                return {
                    "err": "params.douban_apikey.invalid",
                    "msg": _(
                        "豆瓣API密钥无效, 只能包含数字、字母、下划线或短横线，且长度不能超过48个字符"
                    ),
                }
        need_sync_authors = args.get("ENABLE_AUTHOR_INFO", False) and not CONF.get(
            "ENABLE_AUTHOR_INFO", False
        )
        # 管理员保存设置页 = 已看过并确认过侧边栏列表：无条件置迁移标记为真，让
        # SIDEBAR_ITEMS 从此以 stored 为权威、读取期不再补齐陈旧默认。放在 args 上，
        # save_extra_settings 内 CONF.update(args) 更新内存、args.dumpfile() 落盘，
        # 之后每次普通保存都会重申 True，前端 payload 无论带什么都不可能把它抹回假。
        args[SIDEBAR_ITEMS_MIGRATED_KEY] = True
        result = SettingsSaver().save_extra_settings(args)
        perf.apply_logging()
        if need_sync_authors:
            BookBarnService().sync_author_list()
        return result


class AdminInstall(BaseHandler):
    def should_be_invited(self):
        pass

    def should_be_installed(self):
        pass

    @js
    def get(self):
        installed = CONF.get("installed", False)
        err = "installed" if installed else "not_intalled"
        return {"err": err, "installed": installed}

    @js
    def post(self):
        if CONF.get("installed", False):
            return {"err": "installed", "msg": _("不可重复执行安装操作")}

        code = self.get_argument("code", "").strip()
        email = self.get_argument("email", "").strip().lower()
        title = self.get_argument("title", "").strip()
        language = self.get_argument("language", "").strip().lower()
        invite = self.get_argument("invite", "").strip()
        username = self.get_argument("username", "").strip().lower()
        password = self.get_argument("password", "").strip()
        if not username or not password or not email or not title:
            return {"err": "params.invalid", "msg": _("填写的内容有误")}
        if not re.match(Reader.RE_EMAIL, email):
            return {"err": "params.email.invalid", "msg": _("Email无效")}
        if (
            len(username) < 3
            or len(username) > 20
            or not re.match(Reader.RE_USERNAME, username)
        ):
            return {"err": "params.username.invalid", "msg": _("用户名无效")}
        ok, code, msg = Reader.check_password_strength(password)
        if not ok:
            return {"err": code, "msg": msg}

        # 避免重复创建
        user = (
            self.sqlite_session.query(Reader)
            .filter(Reader.username == username)
            .first()
        )
        if not user:
            user = Reader()
            user.username = username
            user.name = username
            user.create_time = datetime.datetime.now()

        # 设置admin user的信息
        user.permission = ""  # Full permission
        user.email = email
        user.avatar = "reader.svg"
        user.update_time = datetime.datetime.now()
        user.access_time = datetime.datetime.now()
        user.active = True
        user.admin = True
        user.extra = {"kindle_email": ""}
        user.set_secure_password(password)
        try:
            user.save()
        except:
            logging.error(traceback.format_exc())
            return {"err": "db.error", "msg": _("系统异常，请重试或更换注册信息")}

        args = loader.SettingsLoader()
        args.clear()

        # inherit the basic path from system's config
        args["settings_path"] = CONF["settings_path"]

        # set options for China user
        # TODO: maybe it should be provided as an install options
        args["avatar_service"] = "https://cravatar.cn"
        args["BOOK_NAMES_FORMAT"] = "utf8"

        # set a random secret
        args["cookie_secret"] = "%s" % uuid.uuid1()
        args["site_title"] = title
        lang = normalize_language(language)
        args["site_language"] = lang if lang in ("zh", "en") else "zh"
        if invite == "true" and code:
            args["INVITE_MODE"] = True
            args["INVITE_CODE"] = code
        else:
            args["INVITE_MODE"] = False

        apply_localized_default_settings(args, args["site_language"])

        return SettingsSaver().save_extra_settings(args)


class SSLHandlerLogic:
    def check_ssl_chain(self, crt_body, key_body):
        """return None if ok, else Err"""
        with tempfile.NamedTemporaryFile() as crt_file, tempfile.NamedTemporaryFile() as key_file:
            crt_file.write(crt_body)
            key_file.write(key_body)
            crt_file.flush()
            key_file.flush()
            return self.check_ssl_chain_files(crt_file.name, key_file.name)

    def check_ssl_chain_files(self, crt_file, key_file):
        ctx = ssl.SSLContext()
        try:
            ctx.load_cert_chain(crt_file, key_file)
        except ssl.SSLError as err:
            return err
        return None

    def save_files(self, crt_body, key_body):
        with open(CONF["ssl_crt_file"], "w+b") as f:
            f.write(crt_body)

        with open(CONF["ssl_key_file"], "w+b") as f:
            f.write(key_body)

    def nginx_check(self):
        # 无超时的同步 subprocess 在 handler 里跑：nginx 卡住（配置死锁、
        # 信号量丢失）会把整个请求乃至 ioloop 挂死，必须给兜底时限
        return subprocess.run(["nginx", "-t"], check=True, timeout=60)

    def nginx_reload(self):
        return subprocess.run(["service", "nginx", "reload"], check=True, timeout=60)

    def run(self, ssl_crt, ssl_key):
        err = self.check_ssl_chain(ssl_crt, ssl_key)
        if err is not None:
            return {"err": "params.ssl_error", "msg": _("证书或密钥校验失败: %s" % err)}

        try:
            self.save_files(ssl_crt, ssl_key)
        except Exception as err:
            import traceback

            logging.error(traceback.format_exc())
            return {
                "err": "internal.ssl_save_error",
                "msg": _("证书存储失败: %s" % err),
            }

        # testing nginx config
        try:
            self.nginx_check()
        except subprocess.CalledProcessError as err:
            return {
                "err": "internal.nginx_test_error",
                "msg": _("NGINX配置异常: %s") % err,
            }
        except subprocess.TimeoutExpired:
            return {
                "err": "internal.nginx_test_error",
                "msg": _("NGINX配置检测超时，请检查 nginx 状态"),
            }

        # reload nginx config
        try:
            self.nginx_reload()
        except subprocess.CalledProcessError as err:
            return {
                "err": "internal.nginx_reload_error",
                "msg": _("NGINX重新加载配置异常: %s") % err,
            }
        except subprocess.TimeoutExpired:
            return {
                "err": "internal.nginx_reload_error",
                "msg": _("NGINX重新加载超时，请检查 nginx 状态"),
            }

        return {"err": "ok", "msg": _("成功")}


class AdminSSL(BaseHandler):
    def get_upload_file(self):
        # for unittest mock
        ssl_crt = self.request.files["ssl_crt"][0]
        ssl_key = self.request.files["ssl_key"][0]
        return (ssl_crt["body"], ssl_key["body"])

    # TODO:
    #   - add GET interface to show the hostname/outdate of certifacates

    @js
    @auth
    def post(self):
        logic = SSLHandlerLogic()

        logging.error("got request")
        if not self.is_admin():
            return {"err": "permission", "msg": _("无权操作")}

        ssl_crt, ssl_key = self.get_upload_file()
        return logic.run(ssl_crt, ssl_key)


class AdminBookList(BaseHandler):
    def _search_book_ids(self, search, sort, ascending):
        self.calibre_db.sort(field=sort, ascending=ascending)
        return list(self.calibre_db_cache.search(search))

    @js
    @is_admin
    async def get(self):
        if not self.admin_user:
            return {"err": "permission.not_admin", "msg": _("当前用户非管理员")}

        num = max(10, int(self.get_argument("num", 20)))
        page = max(0, int(self.get_argument("page", 1)) - 1)
        sort = self.get_argument("sort", "id")
        desc = self.get_argument("desc", "desc") == "true"
        search = self.get_argument("search", "").strip()
        book_type = int(self.get_argument("type", -1))
        logging.debug(
            "num=%d, page=%d, sort=%s, desc=%s, book_type=%d"
            % (num, page, sort, desc, book_type)
        )
        if book_type >= 0 and book_type <= BOOK_TYPE_PHYSICAL:
            # 不用 f-string 内嵌同种引号（PEP 701 仅 3.12+），兼容 3.11
            _not = "not" if book_type == BOOK_TYPE_EBOOK else ""
            book_type_query = f"{_not} {CALIBRE_COLUMN_BOOK_TYPE}:={BOOK_TYPE_PHYSICAL}"
            if search:
                search = f"({search}) AND {book_type_query}"
            else:
                search = book_type_query
            logging.debug("Adjusted search query: %s" % search)
        start = page * num
        end = start + num
        all_ids = await self.run_calibre_async(
            self._search_book_ids, search, sort, not desc
        )
        total = len(all_ids)

        # sort by id
        if sort == "id":
            all_ids.sort(reverse=desc)

        books = []
        page_ids = all_ids[start:end]
        if page_ids:
            book_rows = await self.get_books_for_list_async(ids=page_ids)
            book_by_id = {book["id"]: book for book in book_rows}
            books = [
                SimpleBookFormatter(book_by_id[book_id], self.cdn_url).format()
                for book_id in page_ids
                if book_id in book_by_id
            ]

        return {"err": "ok", "items": books, "total": total}


class AdminBookFill(BaseHandler):
    @js
    @is_admin
    def get(self):
        s = AutoFillService()
        status = s.status()
        return {
            "err": "ok",
            "msg": _("ok"),
            "status": {
                "total": status["count_total"],
                "skip": status["count_skip"],
                "done": status["count_done"],
                "fail": status["count_fail"],
                "running": status["is_running"],
            },
        }

    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body) if self.request.body else {}
        if req.get("cancel"):
            if not AutoFillService().cancel():
                return {"err": "task.not_running", "msg": _("当前没有正在运行的任务")}
            return {"err": "ok", "msg": _("已取消任务")}

        idlist = req.get("idlist")
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        # 检查是否有正在运行的任务
        filling_status = AutoFillService().status()
        if filling_status["is_running"]:
            return {"err": "task.running", "msg": _("有任务正在运行中，请稍后再试")}

        force = False
        if idlist == "all":
            idlist = list(self.calibre_db_cache.all_book_ids())
        elif isinstance(idlist, list):
            for bid in idlist:
                if not isinstance(bid, int):
                    return {"err": "params.error.idlist", "msg": _("idlist参数错误")}
            force = True
        else:
            return {"err": "params.error.idlist", "msg": _("idlist参数错误")}

        AutoFillService().auto_fill_all(idlist, force=force)
        return {"err": "ok", "msg": _("任务启动成功！请耐心等待，稍后再来刷新页面")}


class AdminBookAIFill(BaseHandler):
    """Admin API: 批量使用 AI 更新指定书籍的信息"""

    @js
    @is_admin
    def get(self):
        status = AIFillInfoService().status()
        return {
            "err": "ok",
            "status": {
                "total": status["count_total"],
                "skip": status["count_skip"],
                "done": status["count_done"],
                "fail": status["count_fail"],
                "running": status["is_running"],
            },
        }

    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body) if self.request.body else {}
        if req.get("cancel"):
            if not AIFillInfoService().cancel():
                return {"err": "task.not_running", "msg": _("当前没有正在运行的任务")}
            return {"err": "ok", "msg": _("已取消任务")}

        idlist = req.get("idlist", [])
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        filling_status = AIFillInfoService().status()
        if filling_status["is_running"]:
            return {"err": "task.running", "msg": _("有 AI 任务正在运行中，请稍后再试")}

        if idlist == "all":
            idlist = list(self.calibre_db_cache.all_book_ids())
        elif isinstance(idlist, list):
            for bid in idlist:
                if not isinstance(bid, int):
                    return {"err": "params.error.idlist", "msg": _("参数错误")}
        else:
            return {"err": "params.error.idlist", "msg": _("参数错误")}

        AIFillInfoService().fill_all(idlist)
        return {"err": "ok", "msg": _("AI 更新任务已启动，请耐心等待")}


class AdminUpdateAllMeta(BaseHandler):
    """Admin API: 批量更新所有书籍的元信息"""

    @js
    @is_admin
    def post(self):
        update_status = MetaDataUpdateService().status()
        if update_status["is_running"]:
            return {"err": "task.running", "msg": _("有更新任务正在运行中，请稍后再试")}

        idlist = list(self.calibre_db_cache.all_book_ids())
        MetaDataUpdateService().update_metadata(self.current_user.id, idlist)
        return {
            "err": "ok",
            "msg": _("批量更新书籍元信息任务已启动，右上角可以查看进度"),
        }


class AdminUpdateDynamicCover(BaseHandler):
    """Admin API: 批量更新所有书籍的动态封面"""

    @js
    @is_admin
    def post(self):
        update_status = DynamicCoverUpdateService().status()
        if update_status["is_running"]:
            return {"err": "task.running", "msg": _("有更新任务正在运行中，请稍后再试")}

        req = tornado.escape.json_decode(self.request.body)
        idlist = req["idlist"]
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        if idlist == "all":
            idlist = list(self.calibre_db_cache.all_book_ids())
        elif isinstance(idlist, list):
            for bid in idlist:
                if not isinstance(bid, int):
                    return {"err": "params.error.idlist", "msg": _("idlist参数错误")}

        DynamicCoverUpdateService().update_cover(
            self.current_user.id, idlist, dynamic_cover=True
        )
        return {
            "err": "ok",
            "msg": _("批量更新书籍动态封面任务已启动，右上角可以查看进度"),
        }


class AdminResetCover(BaseHandler):
    """Admin API: 批量重置所有书籍的动态封面"""

    @js
    @is_admin
    def post(self):
        update_status = DynamicCoverUpdateService().status()
        if update_status["is_running"]:
            return {"err": "task.running", "msg": _("有更新任务正在运行中，请稍后再试")}

        req = tornado.escape.json_decode(self.request.body)
        idlist = req["idlist"]
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        if idlist == "all":
            idlist = list(self.calibre_db_cache.all_book_ids())
        elif isinstance(idlist, list):
            for bid in idlist:
                if not isinstance(bid, int):
                    return {"err": "params.error.idlist", "msg": _("idlist参数错误")}

        DynamicCoverUpdateService().update_cover(
            self.current_user.id, idlist, dynamic_cover=False
        )
        return {
            "err": "ok",
            "msg": _("批量更新书籍动态封面任务已启动，右上角可以查看进度"),
        }


class AdminBookConvertEpub(BaseHandler):
    """Admin API: 批量转换为EPUB"""

    @js
    @is_admin
    def get(self):
        status = BatchConvertService().status()
        return {
            "err": "ok",
            "status": {
                "total": status["count_total"],
                "skip": status["count_skip"],
                "done": status["count_done"],
                "fail": status["count_fail"],
                "running": status["is_running"],
            },
        }

    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body)
        idlist = req.get("idlist", [])
        convert_status = BatchConvertService().status()
        if convert_status["is_running"]:
            return {"err": "task.running", "msg": _("有转换任务正在运行中，请稍后再试")}

        if idlist:
            if not isinstance(idlist, list):
                return {
                    "err": "params.error.idlist",
                    "msg": _("参数错误, 未指定正确的id列表"),
                }
            for bid in idlist:
                if not isinstance(bid, int):
                    return {
                        "err": "params.error.idlist",
                        "msg": _("参数错误, id列表中包含无效的id"),
                    }

        if not idlist:
            idlist = list(self.calibre_db_cache.all_book_ids())

        BatchConvertService().convert_all(self.current_user.id, idlist)
        return {"err": "ok", "msg": _("Kindle转EPUB任务已启动，右上角可以查看进度")}


class AdminBookUpdateTitleSort(BaseHandler):
    """Admin API: 批量更新title_sort为拼音排序"""

    @js
    @is_admin
    def get(self):
        status = BatchTitleSortUpdateService().status()
        return {
            "err": "ok",
            "status": {
                "total": status["count_total"],
                "skip": status["count_skip"],
                "done": status["count_done"],
                "fail": status["count_fail"],
                "running": status["is_running"],
            },
        }

    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body)
        idlist = req.get("idlist", [])
        update_status = BatchTitleSortUpdateService().status()
        if update_status["is_running"]:
            return {"err": "task.running", "msg": _("有更新任务正在运行中，请稍后再试")}

        if idlist:
            if not isinstance(idlist, list):
                return {
                    "err": "params.error.idlist",
                    "msg": _("参数错误, 未指定正确的id列表"),
                }
            for bid in idlist:
                if not isinstance(bid, int):
                    return {
                        "err": "params.error.idlist",
                        "msg": _("参数错误, id列表中包含无效的id"),
                    }

        if not idlist:
            idlist = list(self.calibre_db_cache.all_book_ids())

        BatchTitleSortUpdateService().update_all(self.current_user.id, idlist)
        return {"err": "ok", "msg": _("更新书名信息任务已启动，右上角可以查看进度")}


class AdminBookbarnTokenApply(BaseHandler):
    @js
    @is_admin
    def post(self):
        bookbarn = BookBarnClient()
        try:
            token = bookbarn.apply_token(os=self.get_os())
            return {"err": "ok", "msg": _("Token申请成功"), "token": token}
        except Exception as e:
            logging.error(traceback.format_exc())
            return {"err": "params.error", "msg": _("Token申请失败: %s") % str(e)}


class AdminDeleteBooks(BaseHandler):
    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body)
        idlist = req.get("idlist", [])
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        # self.delete_book() 统一处理 calibre 侧删除，以及 Item/ReadingState/BookReview/
        # ReadingRecord（收藏/在读状态、评价、共读同步记录）的级联清理，见其实现。
        for book_id in idlist:
            try:
                AudioUtils.clear_audio(book_id)
                book = self.get_book(book_id)
                if book:
                    self.delete_book(book["id"], book.get("title", ""))
            except Exception as err:
                logging.error(_("执行异常: %s"), err)

        return {"err": "ok", "msg": _("删除成功")}


class AdminSaveMeta(BaseHandler):
    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body)
        idlist = req.get("idlist", [])
        if not idlist:
            return {"err": "params.error", "msg": _("参数错误")}

        for bid in idlist:
            if not isinstance(bid, int):
                return {"err": "params.error.idlist", "msg": _("idlist参数错误")}

        SaveMetaToFilesService().save_metadata(self.current_user.id, idlist)
        return {
            "err": "ok",
            "msg": _("同步元数据到文件的任务已经开始执行，在右上角可以查看进度"),
        }


class ClearInvalidItems(BaseHandler):
    """Admin API: 清理在Calibre中已不存在的无效Items记录"""

    @js
    @is_admin
    def post(self):
        try:
            all_calibre_ids = set(self.calibre_db_cache.all_book_ids())
            items = self.sqlite_session.query(Item).all()
            invalid_items = [
                item for item in items if item.book_id not in all_calibre_ids
            ]
            count = len(invalid_items)
            for item in invalid_items:
                logging.info("[CLEAR]Invalid item with book_id=%s", item.book_id)
                self.sqlite_session.delete(item)
            self.sqlite_session.commit()
            return {
                "err": "ok",
                "msg": _("已清理 %d 条无效图书记录") % count,
                "count": count,
            }
        except Exception as e:
            logging.error("[CLEAR]Failed to clear invalid items: %s", e)
            return {"err": "error", "msg": _("清理失败: %s") % str(e)}


class AudioTestConnection(BaseHandler):
    @js
    @auth
    async def post(self):
        try:
            data = tornado.escape.json_decode(self.request.body)
            proxy = data.get("proxy", None)
            use_bookbarn_proxy = data.get("use_bookbarn_proxy", False)
            if use_bookbarn_proxy:
                return {"err": "ok", "msg": _("EdgeTTS 连接测试成功")}

            if not proxy:
                proxy = None
            else:
                if not re.match(r"^https?://", proxy, re.IGNORECASE) or len(proxy) < 10:
                    return {"err": "params.error.proxy", "msg": _("无效的代理地址")}

            import edge_tts

            voices = await edge_tts.list_voices(proxy=proxy)
            if not voices:
                return {"err": "error", "msg": _("无法获得可用的语音选项")}
            return {"err": "ok", "msg": _("EdgeTTS 连接测试成功")}
        except Exception as e:
            logging.error(f"EdgeTTS 连接测试失败: {e}")
            return {"err": "error", "msg": _("EdgeTTS 连接测试失败: %s") % str(e)}


class ReleaseNotes(BaseHandler):
    @js
    def get(self):
        last_revsion = CONF.get("LAST_REVISION", "")
        force = self.get_argument("force", "false") == "true"
        logging.info("Current version: %s, Last revision: %s", VERSION, last_revsion)
        if last_revsion != VERSION:
            args = loader.SettingsLoader()
            args["LAST_REVISION"] = VERSION
            SettingsSaver().save_extra_settings(args)

        if last_revsion != VERSION or force:
            # Load the release notes from the public folder
            release_note_path = CONF["static_path"] + "/static/release_notes.txt"
            notes = ""
            if os.path.exists(release_note_path):
                with open(release_note_path, "r", encoding="utf-8") as f:
                    notes = f.read()
            else:
                logging.error("Release note file not found")
            return {"err": "ok", "msg": notes}
        else:
            return {"err": "ok", "msg": ""}


class ThanksTo(BaseHandler):
    @js
    def get(self):
        thanks_to_path = CONF["static_path"] + "/static/thanks_to.txt"
        names = []
        if os.path.exists(thanks_to_path):
            with open(thanks_to_path, "r", encoding="utf-8") as f:
                content = f.read()
            names = [name.strip() for name in content.split(",") if name.strip()]
        else:
            logging.error("Thanks-to file not found")
        return {"err": "ok", "names": names}


class AdminTokenHandler(BaseHandler):
    @js
    @auth
    def get(self):
        """Generate and return a new MCP token"""
        if not self.admin_user:
            return {"err": "permission.not_admin", "msg": _("当前用户非管理员")}

        # Generate a random 32-character token using secure random
        import secrets
        import string

        chars = string.ascii_letters + string.digits
        token = "".join(secrets.choice(chars) for _ in range(32))

        return {"err": "ok", "token": token}


class AdminPerf(BaseHandler):
    @js
    @is_admin
    def get(self):
        perf = PerfMonitor.instance().snapshot()
        perf["library_books"] = len(self.calibre_db_cache.all_book_ids())
        from webserver.handlers.static_files import ImageHandler

        cache = ImageHandler.thumb_cache()
        perf["thumb_cache"] = cache.stats() if cache else None
        from webserver.base import calibre_fast

        perf["book_cache"] = calibre_fast.row_cache.stats()
        return {"err": "ok", "perf": perf}

    @js
    @is_admin
    def post(self):
        PerfMonitor.instance().reset()
        return {"err": "ok"}


class AdminRunningTasks(BaseHandler):
    @js
    def get(self):
        if not self.current_user:
            return {"err": "ok", "tasks": [], "msg": _("未登录")}

        # If not admin user, return empty list
        if not self.admin_user:
            return {"err": "ok", "tasks": [], "msg": _("非管理员用户")}

        # Get all running tasks
        all_tasks = BackgroundService().get_running_tasks()
        running_tasks = [
            task
            for task in all_tasks
            if task["status"] == BackgroundTask.STATUS_RUNNING
        ]

        rsp = {"err": "ok", "tasks": running_tasks}
        # include=recent：把最近结束（含失败）的任务一起返回，失败项带
        # error_message / can_retry / retry_action，供任务面板展示并重试。
        if self.get_argument("include", "") == "recent":
            try:
                within_hours = max(1, min(24 * 7, int(self.get_argument("hours", 24))))
            except (TypeError, ValueError):
                within_hours = 24
            recent = BackgroundService().get_recent_tasks(within_hours=within_hours)
            rsp["recent"] = [t for t in recent if t["status"] != BackgroundTask.STATUS_RUNNING]
        if self.get_argument("with_messages", "0") == "1":
            rows, _total = Message.unread_page(self.sqlite_session, self.current_user.id)
            rsp["messages"] = [m.to_brief() for m in rows]
        return rsp


class AdminRestartServer(BaseHandler):
    """Admin API: 重启服务，进程退出后由 supervisor 自动拉起"""

    @js
    @is_admin
    def post(self):
        logging.warning(
            "[ADMIN] Server restart requested by user %s", self.current_user.username
        )
        tornado.ioloop.IOLoop.current().call_later(1, lambda: sys.exit(0))
        return {"err": "ok", "msg": _("服务正在重启，请稍后刷新页面")}


class AdminTrashSize(BaseHandler):
    @js
    @auth
    def get(self):
        if not self.admin_user:
            return {"err": "ok", "sizes": {}, "msg": _("非管理员用户")}
        sizes = TrashManager.get_trash_sizes()
        return {"err": "ok", "sizes": sizes}


class AdminTrashClear(BaseHandler):
    @js
    @auth
    def post(self):
        if not self.admin_user:
            return {
                "err": "permission.not_admin",
                "msg": _("当前用户非管理员, 无权操作"),
            }
        errors = TrashManager.clear_trashs()
        if errors:
            return {"err": "error", "msg": _("清理失败: %s") % "; ".join(errors)}
        return {"err": "ok", "msg": _("已清理Calibre回收站及上传目录")}


class AdminTrashBooks(BaseHandler):
    @js
    @auth
    def get(self):
        if not self.admin_user:
            return {
                "err": "permission.not_admin",
                "msg": _("当前用户非管理员, 无权操作"),
            }
        with self.db_lock:
            books = TrashManager.list_trash_books(self.calibre_db_cache)
        return {"err": "ok", "books": books}


class AdminTrashBooksRestore(BaseHandler):
    @js
    @auth
    def post(self):
        if not self.admin_user:
            return {
                "err": "permission.not_admin",
                "msg": _("当前用户非管理员, 无权操作"),
            }
        req = tornado.escape.json_decode(self.request.body)
        book_ids = req.get("book_ids", [])
        if not book_ids:
            return {"err": "params.error", "msg": _("参数错误")}
        with self.db_lock:
            ok, failed = TrashManager.restore_trash_books(
                self.calibre_db_cache, book_ids
            )
            if ok:
                self.calibre_db.data.books_added(tuple(ok))
        for book_id in ok:
            self._recreate_item_for_restored_book(book_id)
        if failed:
            return {
                "err": "error" if not ok else "partial",
                "msg": _("部分书籍恢复失败: %s") % failed,
                "restored": ok,
                "failed": failed,
            }
        return {"err": "ok", "msg": _("已恢复选中的书籍"), "restored": ok}

    def _recreate_item_for_restored_book(self, book_id):
        """从回收站恢复书籍后，参照 BookUpload 补建 Item 记录并触发元数据刮削（不发送邮件提醒）"""
        try:
            existing_item = (
                self.sqlite_session.query(Item).filter(Item.book_id == book_id).first()
            )
            if not existing_item:
                item = Item()
                item.book_id = book_id
                item.collector_id = self.user_id()
                self.sqlite_session.add(item)
                self.sqlite_session.commit()
            if CONF.get(AUTO_FILL_META, False):
                AutoFillService().auto_fill(book_id)
        except Exception as e:
            logging.error("恢复书籍 %s 后补建Item/刮削失败: %s", book_id, e)


class AdminTrashBooksPurge(BaseHandler):
    @js
    @auth
    def post(self):
        if not self.admin_user:
            return {
                "err": "permission.not_admin",
                "msg": _("当前用户非管理员, 无权操作"),
            }
        req = tornado.escape.json_decode(self.request.body)
        book_ids = req.get("book_ids", [])
        if not book_ids:
            return {"err": "params.error", "msg": _("参数错误")}
        with self.db_lock:
            ok, failed = TrashManager.purge_trash_books(self.calibre_db_cache, book_ids)
        if failed:
            return {
                "err": "error" if not ok else "partial",
                "msg": _("部分条目删除失败: %s") % failed,
                "purged": ok,
                "failed": failed,
            }
        return {"err": "ok", "msg": _("已彻底删除选中的条目"), "purged": ok}


class AdminStamp(BaseHandler):
    @js
    @auth
    def get(self):
        """获取图章图片"""
        if not self.admin_user:
            return {
                "err": "permission.not_admin",
                "msg": _("当前用户非管理员, 无权操作"),
            }

        if not CONF.get("ENABLE_STAMP_FEATURE", False):
            return {"err": "feature.disabled", "msg": _("图章功能未启用")}

        stamp_path = os.path.join(CONF["static_path"], "logo", "stamp.png")
        if os.path.exists(stamp_path):
            return {"err": "ok", "exists": True}
        return {"err": "ok", "exists": False}

    @auth
    def post(self):
        """上传图章图片"""
        if not self.admin_user:
            self.set_status(403)
            return self.write(
                {"err": "permission.not_admin", "msg": _("当前用户非管理员, 无权操作")}
            )

        if "file" not in self.request.files:
            self.set_status(400)
            return self.write({"err": "params.missing", "msg": _("未找到上传的文件")})

        file_info = self.request.files["file"][0]
        filename = file_info["filename"]
        content = file_info["body"]

        # 验证文件格式
        if not filename.lower().endswith(".png"):
            self.set_status(400)
            return self.write(
                {"err": "file.invalid_format", "msg": _("只支持PNG格式的图片")}
            )

        # 验证文件大小
        max_size = 128 * 1024  # 128KB
        if len(content) > max_size:
            self.set_status(400)
            return self.write(
                {"err": "file.too_large", "msg": _("图片文件大小不能超过128KB")}
            )

        # 验证图片尺寸
        try:
            from PIL import Image
            import io

            img = Image.open(io.BytesIO(content))
            if img.width > 480 or img.height > 480:
                self.set_status(400)
                return self.write(
                    {
                        "err": "file.dimension_too_large",
                        "msg": _("图片尺寸不能超过480x480像素"),
                    }
                )
        except Exception as e:
            logging.error(f"Failed to validate image: {e}")
            self.set_status(400)
            return self.write({"err": "file.invalid", "msg": _("无效的图片文件")})

        # 保存图片
        try:
            logo_dir = os.path.join(CONF["static_path"], "logo")
            os.makedirs(logo_dir, exist_ok=True)
            stamp_path = os.path.join(logo_dir, "stamp.png")
            stamp_path_abs = os.path.abspath(stamp_path)
            with open(stamp_path_abs, "wb+") as f:
                f.write(content)
            self.write(
                {
                    "err": "ok",
                    "msg": _("图章图片上传成功"),
                    "data": {"url": self.cdn_url + "/static/logo/stamp.png"},
                }
            )
        except Exception as e:
            logging.error(f"Failed to save stamp image: {e}")
            self.set_status(500)
            self.write(
                {"err": "file.save_failed", "msg": _("保存图片失败: %s") % str(e)}
            )


class LibraryStatsDetail(BaseHandler):
    """书库概览看板：按 kind 分块返回，前端各区域独立异步加载。"""

    # 缓存的是与用户无关的全量数据（标签的阅读范围过滤在返回前按请求做），
    # 否则未登录/受限用户的空结果会被缓存下来，其他用户在 TTL 内都看到空数据。
    _cache = {}
    _refreshing = set()
    _ttl = {"size": 600, "monthly": 60, "tags": 60, "categories": 60}

    def _dir_size(self):
        path = self.calibre_db_cache.backend.library_path
        total = 0
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total

    def _monthly(self):
        year_month = func.strftime("%Y-%m", Item.create_time)
        rows = (
            self.sqlite_session.query(
                year_month, Item.book_type, func.count(Item.book_id), func.sum(Item.book_count)
            )
            .filter(Item.create_time.isnot(None))
            .group_by(year_month, Item.book_type)
            .all()
        )
        data = {}
        for ym, book_type, cnt, phys in rows:
            d = data.setdefault(ym, {"month": ym, "ebook": 0, "physical": 0})
            if book_type == 1:
                d["physical"] += int(phys or 0)
            else:
                d["ebook"] += int(cnt or 0)
        return sorted(data.values(), key=lambda x: x["month"], reverse=True)

    def _tags_output(self, tags, limit=50):
        tags = self.filter_tags_by_read_range(tags)
        items = sorted(tags.items(), key=lambda kv: kv[1], reverse=True)[:limit]
        return [{"name": k, "count": v} for k, v in items]

    def _categories(self):
        from webserver.constants import CALIBRE_COLUMN_CATEGORY

        total = len(self.calibre_db_cache.all_book_ids())
        fm = self.calibre_db.field_metadata
        result = []
        categorized = 0
        if CALIBRE_COLUMN_CATEGORY in fm:
            n = fm[CALIBRE_COLUMN_CATEGORY]["colnum"]
            sql = (
                f"SELECT v.value, count(distinct l.book) FROM custom_column_{n} v "
                f"JOIN books_custom_column_{n}_link l ON l.value = v.id "
                "GROUP BY v.id ORDER BY 2 DESC"
            )
            with self.db_lock:
                rows = self.calibre_db_cache.backend.conn.get(sql)
            for name, cnt in rows:
                result.append({"name": name, "count": cnt})
                categorized += cnt
        uncategorized = max(total - categorized, 0)
        return {"items": result, "uncategorized": uncategorized}

    async def _compute(self, kind):
        if kind == "size":
            return await tornado.ioloop.IOLoop.current().run_in_executor(None, self._dir_size)
        if kind == "monthly":
            return self._monthly()
        if kind == "tags":
            return self.query_all_tags_with_count()
        return self._categories()

    async def _refresh(self, kind):
        """重新计算并写入缓存；失败时保留旧缓存。同一 kind 同时只刷新一次。"""
        LibraryStatsDetail._refreshing.add(kind)
        try:
            data = await self._compute(kind)
            LibraryStatsDetail._cache[kind] = (time.time(), data)
            return data
        finally:
            LibraryStatsDetail._refreshing.discard(kind)

    async def _background_refresh(self, kind):
        try:
            await self._refresh(kind)
        except Exception as e:
            logging.error("LibraryStatsDetail refresh %s failed: %s", kind, e)
        finally:
            # 请求结束时 session 已 close，这里后台刷新可能重新用到它，用完再关一次
            self.sqlite_session.close()

    def _output(self, kind, data):
        if kind == "tags":
            data = self._tags_output(data)
        return {"err": "ok", "data": data}

    @js
    async def get(self, kind):
        if kind not in self._ttl:
            return {"err": "params.invalid", "msg": "unknown kind"}
        # 受限用户不发给全库统计（前端据 restricted 隐藏面板），见
        # BaseHandler.is_library_restricted 的说明。
        if self.is_library_restricted():
            return {"err": "ok", "restricted": True}
        cached = LibraryStatsDetail._cache.get(kind)
        if cached:
            # 过期时先返回旧数据，后台刷新（stale-while-revalidate）
            if time.time() - cached[0] >= self._ttl[kind] and kind not in LibraryStatsDetail._refreshing:
                LibraryStatsDetail._refreshing.add(kind)
                tornado.ioloop.IOLoop.current().spawn_callback(self._background_refresh, kind)
            return self._output(kind, cached[1])
        try:
            data = await self._refresh(kind)
        except Exception as e:
            logging.error("LibraryStatsDetail compute %s failed: %s", kind, e)
            return {"err": "stats.failed", "msg": str(e)}
        return self._output(kind, data)


class LibraryStats(BaseHandler):
    _cache_data = None
    _cache_time = 0

    def _get_stats(self):
        now = datetime.datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        total_books = len(self.calibre_db_cache.all_book_ids())
        ebook_count = 0
        physical_count = 0
        month_ebook_count = 0
        month_physical_count = 0

        if total_books:
            physical_count = self.get_physical_books_count()
            ebook_count = total_books - physical_count

            rows = (
                self.sqlite_session.query(Item.book_type, func.count(Item.book_id), func.sum(Item.book_count))
                .filter(Item.create_time >= month_start)
                .group_by(Item.book_type)
                .all()
            )
            for book_type, cnt, phy_sum in rows:
                if book_type == 0:
                    month_ebook_count = cnt
                elif book_type == 1:
                    month_physical_count = phy_sum or 0

        return {
            "total_books": total_books,
            "ebook_count": ebook_count,
            "physical_count": physical_count,
            "month_ebook_count": month_ebook_count,
            "month_physical_count": month_physical_count,
        }

    @js
    def get(self):
        """获取书库统计信息"""
        # 受限用户：不给全库数字，前端隐藏整个统计条
        if self.is_library_restricted():
            return {"err": "ok", "restricted": True}
        now = datetime.datetime.now()
        current_year = now.year
        current_month = now.month

        stats = None
        # check cache
        if time.time() - LibraryStats._cache_time < 30 and LibraryStats._cache_data:
            stats = LibraryStats._cache_data
        else:
            try:
                stats = self._get_stats()
                LibraryStats._cache_data = stats
                LibraryStats._cache_time = time.time()
            except Exception as e:
                logging.error("Failed to get library stats: %s", e)
                if LibraryStats._cache_data:
                    stats = LibraryStats._cache_data
                else:
                    # fallback to empty stats
                    stats = {
                        "total_books": 0,
                        "ebook_count": 0,
                        "physical_count": 0,
                        "month_ebook_count": 0,
                        "month_physical_count": 0,
                    }

        stats["current_year"] = current_year
        stats["current_month"] = current_month
        return {"err": "ok", "stats": stats}


class AdminSyslog(BaseHandler):
    MAX_LINES = 1500

    @js
    @is_admin
    def get(self):
        try:
            if not os.path.exists(LOG_PATH):
                return {"err": "ok", "lines": []}
            with open(LOG_PATH, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            return {
                "err": "ok",
                "lines": [line.rstrip("\n") for line in lines[-self.MAX_LINES :]],
                "href": self.cdn_url + "/api/admin/syslog/download",
            }
        except Exception as e:
            logging.error("Failed to read syslog: %s", e)
            return {"err": "failed", "msg": str(e)}


class AdminSyslogDownload(BaseHandler):
    @is_admin
    def get(self):
        today = datetime.datetime.now().strftime("%Y_%m_%d")
        filename = f"mybooks_log_{today}.log"
        try:
            if not os.path.exists(LOG_PATH):
                content = b""
            else:
                with open(LOG_PATH, "rb") as f:
                    content = f.read()
        except Exception as e:
            logging.error("Failed to read syslog for download: %s", e)
            self.set_status(500)
            self.finish(str(e))
            return
        self.set_header("Content-Type", "text/plain; charset=utf-8")
        self.set_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.set_header("Content-Length", len(content))
        self.finish(content)


class AdminResources(BaseHandler):
    _cache_data = None
    _cache_time = 0

    CACHED_TIME = 7200  # 2 hours

    CONF_DEFAULT_RESOURCES = [
        {
            "icon": "https://dushupai.com/favicon.ico",
            "title": "读书派",
            "link": "https://dushupai.com/",
        },
        {
            "icon": "https://www.huaijiushuku.com/favicon.ico",
            "title": "怀旧书库",
            "link": "https://www.huaijiushuku.com/",
        },
    ]

    @js
    @is_admin
    async def get(self):
        if (
            time.time() - AdminResources._cache_time < AdminResources.CACHED_TIME
            and AdminResources._cache_data
        ):
            logging.info("[Resources]Use cached data")
            resources = AdminResources._cache_data
        else:
            resources = await utils.run_in_threadpool(BookBarnClient().get_resource_list, CONF.get("BOOKBARN_TOKEN", ""))
            resources = (
                resources if resources else AdminResources.CONF_DEFAULT_RESOURCES
            )
            AdminResources._cache_data = resources
            AdminResources._cache_time = time.time()

            need_loading_urls = []
            for res in resources:
                if "icon" in res and res["icon"]:
                    need_loading_urls.append(res["icon"])
                    res["icon"] = ResourceService.check_favicon(res["icon"])
            if need_loading_urls:
                ResourceService().load_favicons(need_loading_urls, flag=1)

        return {"err": "ok", "resources": resources}


class AdminAITestConnection(BaseHandler):
    @js
    @is_admin
    async def post(self):
        data = tornado.escape.json_decode(self.request.body)
        api_url = data.get("api_url", None)
        api_key = data.get("api_key", None)
        api_model = data.get("api_model", None)
        if not api_url or not api_key or not api_model:
            return {
                "err": "params.error",
                "msg": _("缺少必要的参数，请确认API信息填写完整"),
            }

        try:
            # 同步 OpenAI 客户端连接测试（服务不可达时等待到超时），下放线程池避免冻住 ioloop
            result, msg = await utils.run_in_threadpool(
                BookAIClient(api_url, api_key, api_model).test_connection
            )
            if result:
                return {"err": "ok", "msg": _("AI服务连接测试成功")}
            return {"err": "error", "msg": _("AI服务连接测试失败: %s") % msg}
        except Exception as e:
            logging.error(f"AI服务连接测试异常: {e}")
            return {"err": "error", "msg": _("AI服务连接测试异常: %s") % str(e)}


class AuthorInfo(BaseHandler):
    @js
    def get(self):
        name = self.get_argument("name", "")
        if not name:
            return {"err": "params.error", "msg": _("参数错误")}

        author = self.sqlite_session.query(Authors).filter(Authors.name == name).first()
        if author is None:
            return {"err": "ok", "author": None}
        data = author.to_dict()
        if data.get("create_time"):
            data["create_time"] = data["create_time"].isoformat()
        return {"err": "ok", "author": data}


class AdminAuthorBio(BaseHandler):
    @js
    @is_admin
    def post(self):
        req = tornado.escape.json_decode(self.request.body)
        name = (req.get("name") or "").strip()
        bio = req.get("bio") or ""

        if not name:
            return {"err": "params.error", "msg": _("参数错误")}
        if len(bio) > 4096:
            return {"err": "params.bio.too_long", "msg": _("简介内容过长")}

        author = self.sqlite_session.query(Authors).filter(Authors.name == name).first()
        if author is None:
            author = Authors(name=name, sort="")
            self.sqlite_session.add(author)
        author.bio = bio
        self.sqlite_session.commit()

        data = author.to_dict()
        if data.get("create_time"):
            data["create_time"] = data["create_time"].isoformat()
        return {"err": "ok", "msg": _("简介保存成功"), "author": data}


class AdminUpdateAuthor(BaseHandler):
    @js
    @is_admin
    def post(self):
        if not CONF.get("ENABLE_BOOKBARN", False) or not CONF.get("BOOKBARN_TOKEN", ""):
            return {"err": "params.error", "msg": _("请先启用并配置书栈服务")}

        req = tornado.escape.json_decode(self.request.body)
        name = req.get("name", "")
        if not name:
            return {"err": "params.error", "msg": _("参数错误")}

        BookBarnService().update_author_async(name, admin_uid=self.user_id())
        return {"err": "ok", "msg": _("已提交更新，请稍后刷新查看")}


class AdminSysInfo(BaseHandler):
    @js
    def get(self):
        if CONF.get("installed", None) is False:
            return {"err": "not_installed"}

        return {"err": "ok", "data": self.get_sys_info()}


def routes():
    return [
        (r"/api/admin/ssl", AdminSSL),
        (r"/api/admin/users", AdminUsers),
        (r"/api/admin/book-reviews", AdminBookReviews),
        (r"/api/admin/install", AdminInstall),
        (r"/api/admin/settings", AdminSettings),
        (r"/api/admin/testmail", AdminTestMail),
        (r"/api/admin/book/list", AdminBookList),
        (r"/api/admin/book/fill", AdminBookFill),
        (r"/api/admin/book/aifill", AdminBookAIFill),
        (r"/api/admin/book/epubconvert", AdminBookConvertEpub),
        (r"/api/admin/book/update_title_sort", AdminBookUpdateTitleSort),
        (r"/api/admin/bookbarn/token/apply", AdminBookbarnTokenApply),
        (r"/api/admin/books/delete", AdminDeleteBooks),
        (r"/api/admin/books/save_meta", AdminSaveMeta),
        (r"/api/admin/clear/invalid/items", ClearInvalidItems),
        (r"/api/admin/audio/test", AudioTestConnection),
        (r"/api/admin/release/notes", ReleaseNotes),
        (r"/api/admin/thanks/notes", ThanksTo),
        (r"/api/admin/token", AdminTokenHandler),
        (r"/api/admin/tasks/running", AdminRunningTasks),
        (r"/api/admin/perf", AdminPerf),
        (r"/api/admin/trash/size", AdminTrashSize),
        (r"/api/admin/trash/clear", AdminTrashClear),
        (r"/api/admin/trash/books", AdminTrashBooks),
        (r"/api/admin/trash/books/restore", AdminTrashBooksRestore),
        (r"/api/admin/trash/books/purge", AdminTrashBooksPurge),
        (r"/api/admin/restart", AdminRestartServer),
        (r"/api/admin/stamp", AdminStamp),
        (r"/api/library/stats", LibraryStats),
        (r"/api/library/stats/(size|monthly|tags|categories)", LibraryStatsDetail),
        (r"/api/admin/syslog", AdminSyslog),
        (r"/api/admin/book/update_all_meta", AdminUpdateAllMeta),
        (r"/api/admin/book/update_all_dynamic_cover", AdminUpdateDynamicCover),
        (r"/api/admin/book/reset_cover", AdminResetCover),
        (r"/api/admin/syslog/download", AdminSyslogDownload),
        (r"/api/admin/resources", AdminResources),
        (r"/api/admin/ai/test", AdminAITestConnection),
        (r"/api/sysinfo", AdminSysInfo),
        (r"/api/author/info", AuthorInfo),
        (r"/api/author/bio", AdminAuthorBio),
        (r"/api/admin/update_author", AdminUpdateAuthor),
    ]
