from .djvu_rs import *

__doc__ = djvu_rs.__doc__
if hasattr(djvu_rs, "__all__"):
    __all__ = djvu_rs.__all__